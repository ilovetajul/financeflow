import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:financeflow/data/local/database_helper.dart';
import 'package:financeflow/domain/models/debt_model.dart';
import 'package:financeflow/domain/models/transaction.dart';
import 'package:financeflow/presentation/debt_linked_guard.dart';
import 'package:financeflow/presentation/providers/debt_provider.dart';
import 'package:financeflow/presentation/providers/transaction_provider.dart';
import 'package:financeflow/presentation/screens/category/category_screen.dart';
import 'package:financeflow/presentation/screens/edit_transaction/edit_transaction_screen.dart';
import 'test_helpers.dart';

/// Category provider that never touches the database (the widget tests below do
/// not need real categories).
class _NoDbCategories extends CategoryNotifier {
  @override
  Future<void> load() async {}
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(initFfi);

  group('model', () {
    test('isDebtLinked is true exactly when sourceId is set', () {
      expect(tx('a').isDebtLinked, false);
      expect(tx('b', sourceId: 'd1').isDebtLinked, true);
    });
  });

  group('provider protection (real database)', () {
    late DatabaseHelper h;
    late ProviderContainer c;

    setUp(() async {
      h = await openTestDb();
      c = ProviderContainer();
      addTearDown(c.dispose);
    });
    tearDown(() async => DatabaseHelper.resetForTesting());

    /// Creates person p1 and a debt transaction d1 (৳5,000, "gave") that also
    /// writes a linked ledger entry, exactly like the debt screen does.
    Future<Transaction> createLinkedEntry() async {
      await c.read(debtPersonsProvider.notifier).addPerson(person('p1'));
      await c.read(debtTransactionsProvider.notifier).add(
            dtx('d1', 'p1', DebtType.gave, 5000),
            affectMain: true,
          );
      final all = await c.read(transactionsProvider.future);
      return all.firstWhere((t) => t.sourceId == 'd1');
    }

    test('the linked ledger entry is created with sourceId = debt transaction id', () async {
      final linked = await createLinkedEntry();
      expect(linked.isDebtLinked, true);
      expect(linked.amount, 5000);
    });

    test('editing a debt-linked entry is refused and nothing changes', () async {
      final linked = await createLinkedEntry();
      await expectLater(
        c.read(transactionsProvider.notifier).edit(linked.copyWith(amount: 8000)),
        throwsA(isA<LinkedTransactionException>()),
      );
      final stored = (await h.getAllTransactions()).firstWhere((t) => t.id == linked.id);
      expect(stored.amount, 5000);
      expect(stored.sourceId, 'd1');
    });

    test('deleting a debt-linked entry is refused and nothing changes', () async {
      final linked = await createLinkedEntry();
      await expectLater(
        c.read(transactionsProvider.notifier).remove(linked.id),
        throwsA(isA<LinkedTransactionException>()),
      );
      expect((await h.getAllTransactions()).map((t) => t.id), contains(linked.id));
    });

    test('a stale copy without sourceId cannot bypass the protection (the stored row decides)', () async {
      final linked = await createLinkedEntry();
      final stale = Transaction(
        id: linked.id,
        type: linked.type,
        category: linked.category,
        amount: 1,
        note: 'tampered',
        date: linked.date,
        icon: linked.icon,
        // sourceId deliberately omitted
      );
      await expectLater(
        c.read(transactionsProvider.notifier).edit(stale),
        throwsA(isA<LinkedTransactionException>()),
      );
      final stored = (await h.getAllTransactions()).firstWhere((t) => t.id == linked.id);
      expect(stored.amount, 5000);
      expect(stored.note, isNot('tampered'));
    });

    test('the refusal carries the Bengali explanation', () {
      expect(LinkedTransactionException().userMessage, kDebtLinkedMessage);
      expect(kDebtLinkedMessage, contains('দেনা-পাওনা'));
    });

    test('ordinary transactions (sourceId == null) can still be edited and deleted', () async {
      await h.insertTransaction(tx('plain', amount: 100));
      final n = c.read(transactionsProvider.notifier);
      await c.read(transactionsProvider.future);

      await n.edit(tx('plain', amount: 250));
      expect((await h.getAllTransactions()).firstWhere((t) => t.id == 'plain').amount, 250);

      await n.remove('plain');
      expect((await h.getAllTransactions()).where((t) => t.id == 'plain'), isEmpty);
    });

    test('deleting the DEBT transaction still removes its linked ledger entry', () async {
      final linked = await createLinkedEntry();
      await c.read(debtTransactionsProvider.notifier).delete('d1');
      expect((await h.getAllTransactions()).where((t) => t.id == linked.id), isEmpty);
      expect(await h.getAllDebtTransactions(), isEmpty);
    });

    test('deleting the PERSON still removes linked ledger entries', () async {
      final linked = await createLinkedEntry();
      await c.read(debtPersonsProvider.notifier).deletePerson('p1');
      expect((await h.getAllTransactions()).where((t) => t.id == linked.id), isEmpty);
    });
  });

  group('UI', () {
    Future<void> pumpEdit(WidgetTester t, Transaction tr) async {
      t.view.physicalSize = const Size(420, 1200);
      t.view.devicePixelRatio = 1.0;
      addTearDown(t.view.reset);
      await t.pumpWidget(ProviderScope(
        overrides: [categoriesProvider.overrideWith((ref) => _NoDbCategories())],
        child: MaterialApp(home: EditTransactionScreen(transaction: tr)),
      ));
      await t.pump();
    }

    testWidgets('Edit screen for a debt-linked entry shows the explanation and no edit/delete controls', (t) async {
      await pumpEdit(t, tx('m1', amount: 5000, sourceId: 'd1'));
      expect(find.text(kDebtLinkedMessage), findsOneWidget);
      expect(find.byIcon(Icons.delete_rounded), findsNothing);
      expect(find.textContaining('Update করো'), findsNothing);
    });

    testWidgets('Edit screen for an ordinary entry is unchanged (editor and delete button present)', (t) async {
      await pumpEdit(t, tx('plain', amount: 100));
      expect(find.text(kDebtLinkedMessage), findsNothing);
      expect(find.byIcon(Icons.delete_rounded), findsOneWidget);
      expect(find.textContaining('Update করো'), findsOneWidget);
    });

    testWidgets('blockIfDebtLinked blocks linked entries with a message and lets ordinary ones through', (t) async {
      late bool linkedBlocked;
      late bool plainBlocked;
      await t.pumpWidget(MaterialApp(
        home: Scaffold(
          body: Builder(
            builder: (context) => TextButton(
              onPressed: () {
                plainBlocked = blockIfDebtLinked(context, tx('plain'));
                linkedBlocked = blockIfDebtLinked(context, tx('m1', sourceId: 'd1'));
              },
              child: const Text('go'),
            ),
          ),
        ),
      ));
      await t.tap(find.text('go'));
      await t.pump();
      expect(plainBlocked, false);
      expect(linkedBlocked, true);
      expect(find.text(kDebtLinkedMessage), findsOneWidget);
    });
  });
}
