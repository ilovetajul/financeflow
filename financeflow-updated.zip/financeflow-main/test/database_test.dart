import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:path/path.dart' as p;
import 'package:financeflow/data/local/database_helper.dart';
import 'package:financeflow/data/local/migration_service.dart';
import 'package:financeflow/domain/models/debt_model.dart';
import 'package:financeflow/domain/models/transaction.dart';
import 'test_helpers.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(initFfi);
  tearDown(() async => DatabaseHelper.resetForTesting());

  group('transactions', () {
    test('add income / expense, edit, delete', () async {
      final h = await openTestDb();
      await h.insertTransaction(tx('a', type: TransactionType.income, amount: 500));
      await h.insertTransaction(tx('b', amount: 120.5));
      var all = await h.getAllTransactions();
      expect(all.length, 2);

      await h.updateTransaction(tx('b', amount: 99.25, type: TransactionType.income));
      all = await h.getAllTransactions();
      final b = all.firstWhere((t) => t.id == 'b');
      expect(b.amount, 99.25);
      expect(b.type, TransactionType.income);

      await h.deleteTransaction('a');
      expect((await h.getAllTransactions()).map((t) => t.id), ['b']);
    });

    test('null note in database does not crash parsing', () async {
      final h = await openTestDb();
      final db = await h.database;
      await db.insert('transactions', {
        'id': 'n', 'type': 'income', 'category': 'বেতন', 'amount': 1.0,
        'note': null, 'date': '2026-01-01T00:00:00.000', 'icon': '💼',
      });
      final all = await h.getAllTransactions();
      expect(all.single.note, '');
    });
  });

  group('debt', () {
    test('balance = gave - received; summary counts', () async {
      final h = await openTestDb();
      await h.insertPerson(person('p1'));
      await h.insertDebtTransaction(dtx('d1', 'p1', DebtType.gave, 5000));
      await h.insertDebtTransaction(dtx('d2', 'p1', DebtType.received, 1000));
      final s = await h.getPersonDeletionSummary('p1');
      expect(s.debtTransactionCount, 2);
      expect(s.balance, 4000);
      expect(s.linkedLedgerCount, 0);
    });

    test('foreign key rejects debt transaction for unknown person', () async {
      final h = await openTestDb();
      await expectLater(
          h.insertDebtTransaction(dtx('d1', 'ghost', DebtType.gave, 10)),
          throwsA(anything));
    });

    test('deleting a person removes ALL their debt records and linked ledger entries',
        () async {
      final h = await openTestDb();
      await h.insertPerson(person('p1'));
      await h.insertPerson(person('p2', 'Karim'));
      await h.insertDebtTransaction(dtx('d1', 'p1', DebtType.gave, 5000),
          mirror: tx('m1', amount: 5000, sourceId: 'd1'));
      await h.insertDebtTransaction(dtx('d2', 'p1', DebtType.received, 1000));
      await h.insertDebtTransaction(dtx('d3', 'p2', DebtType.gave, 70));
      await h.insertTransaction(tx('keep'));

      final summary = await h.getPersonDeletionSummary('p1');
      expect(summary.linkedLedgerCount, 1);

      await h.deletePersonCascade('p1');

      final persons = await h.getAllPersons();
      final debts = await h.getAllDebtTransactions();
      expect(persons.map((e) => e.id), ['p2']);
      expect(debts.map((e) => e.id), ['d3']); // no orphans
      expect((await h.getAllTransactions()).map((t) => t.id), ['keep']);
    });

    test('failed person delete rolls back everything', () async {
      final h = await openTestDb();
      await h.insertPerson(person('p1'));
      await h.insertDebtTransaction(dtx('d1', 'p1', DebtType.gave, 5));
      await expectLater(h.deletePersonCascade('does-not-exist'), throwsA(anything));
      expect((await h.getAllDebtTransactions()).length, 1);
      expect((await h.getAllPersons()).length, 1);
    });

    test('deleting a debt transaction removes its linked ledger entry', () async {
      final h = await openTestDb();
      await h.insertPerson(person('p1'));
      await h.insertDebtTransaction(dtx('d1', 'p1', DebtType.gave, 5000),
          mirror: tx('m1', amount: 5000, sourceId: 'd1'));
      await h.deleteDebtTransaction('d1');
      expect(await h.getAllDebtTransactions(), isEmpty);
      expect(await h.getAllTransactions(), isEmpty);
    });

    test('debt + mirror insert is atomic', () async {
      final h = await openTestDb();
      await h.insertPerson(person('p1'));
      await h.insertTransaction(tx('dup'));
      // mirror id collides with an existing ledger row -> whole insert fails
      await expectLater(
          h.insertDebtTransaction(dtx('d1', 'p1', DebtType.gave, 5),
              mirror: tx('dup', sourceId: 'd1')),
          throwsA(anything));
      expect(await h.getAllDebtTransactions(), isEmpty);
    });
  });

  group('schema migration v1 -> v2', () {
    test('existing transactions survive and new structures exist', () async {
      final dir = Directory.systemTemp.createTempSync('ff_mig');
      final path = p.join(dir.path, 'old.db');
      final old = await databaseFactory.openDatabase(path,
          options: OpenDatabaseOptions(
              version: 1,
              onCreate: (db, v) => db.execute('''
                CREATE TABLE transactions (
                  id TEXT PRIMARY KEY, type TEXT NOT NULL, category TEXT NOT NULL,
                  amount REAL NOT NULL, note TEXT, date TEXT NOT NULL, icon TEXT NOT NULL)
              ''')));
      await old.insert('transactions', {
        'id': 't1', 'type': 'expense', 'category': 'খাবার', 'amount': 123.45,
        'note': 'lunch', 'date': '2026-09-30T20:15:00.000', 'icon': '🍜'
      });
      await old.insert('transactions', {
        'id': 't2', 'type': 'income', 'category': 'বেতন', 'amount': 50000.0,
        'note': null, 'date': '2026-09-01T09:00:00.000', 'icon': '💼'
      });
      await old.close();

      final db = await DatabaseHelper.openAtPath(path);
      DatabaseHelper.useDatabaseForTesting(db);
      final rows = await db.query('transactions', orderBy: 'id');
      expect(rows.length, 2);
      expect(rows[0]['amount'], 123.45);
      expect(rows[0]['date'], '2026-09-30T20:15:00.000');
      expect(rows[0]['sourceId'], isNull);
      expect(rows[1]['note'], isNull);
      for (final t in ['categories', 'debt_persons', 'debt_transactions', 'app_meta']) {
        final r = await db.rawQuery(
            "SELECT name FROM sqlite_master WHERE type='table' AND name=?", [t]);
        expect(r, isNotEmpty, reason: t);
      }
      expect((await db.rawQuery('PRAGMA foreign_keys')).first.values.first, 1);
      dir.deleteSync(recursive: true);
    });
  });

  group('MigrationService (SharedPreferences -> SQLite)', () {
    Map<String, Object> oldPrefs({bool orphan = false}) => {
          'debt_persons': jsonEncode([
            {'id': 'p1', 'name': 'Rahim', 'phone': '017', 'imagePath': null},
          ]),
          'debt_transactions': jsonEncode([
            {'id': 'd1', 'personId': 'p1', 'amount': 5000, 'type': 'gave',
             'date': '2026-09-01T10:00:00.000', 'note': 'loan'},
            {'id': 'd2', 'personId': 'p1', 'amount': 1000.5, 'type': 'received',
             'date': '2026-09-10T10:00:00.000', 'note': 'part'},
            if (orphan)
              {'id': 'd3', 'personId': 'deleted', 'amount': 9, 'type': 'gave',
               'date': '2026-09-11T10:00:00.000', 'note': 'orphan'},
          ]),
          'app_categories': jsonEncode([
            {'id': 'c1', 'name': 'Custom', 'icon': '⭐', 'type': 'expense'},
          ]),
        };

    test('copies data, verifies, marks done, keeps old prefs, is idempotent', () async {
      SharedPreferences.setMockInitialValues(oldPrefs());
      final h = await openTestDb();
      final r = await MigrationService(h).runIfNeeded();
      expect(r.success, true);
      expect(r.persons, 1);
      expect(r.debtTransactions, 2);
      expect((await h.getAllPersons()).single.name, 'Rahim');
      final debts = await h.getAllDebtTransactions();
      expect(debts.map((d) => d.amount), [5000, 1000.5]);
      expect((await h.getCategoryRows()).single['name'], 'Custom');
      expect(await h.getMeta(MigrationService.metaDone), 'done');

      final prefs = await SharedPreferences.getInstance();
      expect(prefs.getString('debt_persons'), isNotNull); // old data kept

      // second run changes nothing
      final r2 = await MigrationService(h).runIfNeeded();
      expect(r2.success, true);
      expect((await h.getAllDebtTransactions()).length, 2);
    });

    test('orphan debt transactions are not silently lost', () async {
      SharedPreferences.setMockInitialValues(oldPrefs(orphan: true));
      final h = await openTestDb();
      final r = await MigrationService(h).runIfNeeded();
      expect(r.success, true);
      expect(r.orphansSkipped, 1);
      expect(await h.getMeta('orphan_debt_tx_skipped'), '1');
      final prefs = await SharedPreferences.getInstance();
      expect(prefs.getString('debt_transactions'), contains('orphan'));
    });

    test('fresh install seeds default categories', () async {
      SharedPreferences.setMockInitialValues({});
      final h = await openTestDb();
      final r = await MigrationService(h).runIfNeeded();
      expect(r.success, true);
      expect((await h.getCategoryRows()).length, 14);
    });

    test('corrupt old data fails safely: nothing marked done, nothing written', () async {
      SharedPreferences.setMockInitialValues({'debt_persons': '{not json'});
      final h = await openTestDb();
      final r = await MigrationService(h).runIfNeeded();
      expect(r.success, false);
      expect(r.userMessage, isNotNull);
      expect(await h.getMeta(MigrationService.metaDone), isNull);
      expect(await h.getAllPersons(), isEmpty);
      final prefs = await SharedPreferences.getInstance();
      expect(prefs.getString('debt_persons'), '{not json'); // untouched
    });
  });
}
