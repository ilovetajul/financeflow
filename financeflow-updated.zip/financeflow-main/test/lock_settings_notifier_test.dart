import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:financeflow/data/security/lock_timeout.dart';
import 'package:financeflow/presentation/providers/security_provider.dart';
import 'security_fakes.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late FakeSecretStore store;
  late FlakyPinService pins;

  setUp(() {
    SharedPreferences.setMockInitialValues({});
    store = FakeSecretStore();
    pins = FlakyPinService(store: store, iterations: 2);
  });

  test('normal, PIN disabled: settings are read and the state is not marked failed', () async {
    final n = LockSettingsNotifier(pins);
    expect(await n.reload(), true);
    expect(n.state.pinEnabled, false);
    expect(n.state.loadFailed, false);
  });

  test('normal, PIN enabled: settings are read and the state is not marked failed', () async {
    await pins.setPin('1234');
    final n = LockSettingsNotifier(pins);
    expect(await n.reload(), true);
    expect(n.state.pinEnabled, true);
    expect(n.state.timeout, LockTimeout.minute1);
    expect(n.state.loadFailed, false);
  });

  test('a read failure is reported as a failure, never as "PIN disabled"', () async {
    await pins.setPin('1234'); // a PIN really exists
    final n = LockSettingsNotifier(pins);
    pins.failEnabledRead = true;
    expect(await n.reload(), false);
    expect(n.state.loadFailed, true); // the lock layer fails closed on this flag
  });

  test('a failure after a good load keeps the last known values but marks them untrusted', () async {
    await pins.setPin('1234');
    final n = LockSettingsNotifier(pins);
    await n.reload();
    pins.failEnabledRead = true;
    expect(await n.reload(), false);
    expect(n.state.pinEnabled, true);
    expect(n.state.loadFailed, true);
  });

  test('failing to read the timeout also counts as unreadable security state', () async {
    final n = LockSettingsNotifier(pins);
    pins.failTimeoutRead = true;
    expect(await n.reload(), false);
    expect(n.state.loadFailed, true);
  });

  test('recovery: a later successful read clears the failure', () async {
    await pins.setPin('1234');
    final n = LockSettingsNotifier(pins);
    pins.failEnabledRead = true;
    await n.reload();
    pins.failEnabledRead = false;
    expect(await n.reload(), true);
    expect(n.state.loadFailed, false);
    expect(n.state.pinEnabled, true);
  });
}
