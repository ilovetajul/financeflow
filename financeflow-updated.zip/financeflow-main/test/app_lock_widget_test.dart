import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:financeflow/data/security/lock_timeout.dart';
import 'package:financeflow/data/security/pin_service.dart';
import 'package:financeflow/presentation/providers/security_provider.dart';
import 'package:financeflow/presentation/screens/lock/app_lock_layer.dart';
import 'security_fakes.dart';

const secret = 'SECRET-FINANCIAL-SCREEN';
const pushed = 'PUSHED-DETAIL-SCREEN';
const pinPrompt = '🔐 PIN দিয়ে unlock করো';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late FakeSecretStore store;
  late DateTime clock;
  late PinService pins;
  late GlobalKey<NavigatorState> navKey;

  Future<void> boot({
    Map<String, Object> prefs = const {},
    String? setPin,
    LockTimeout? timeout,
  }) async {
    navKey = GlobalKey<NavigatorState>();
    SharedPreferences.setMockInitialValues(prefs);
    store = FakeSecretStore();
    clock = DateTime(2026, 9, 30, 12);
    pins = PinService(store: store, now: () => clock, iterations: 2);
    if (setPin != null) await pins.setPin(setPin);
    if (timeout != null) await pins.saveTimeout(timeout);
  }

  Future<void> flush(WidgetTester t) async {
    for (var i = 0; i < 8; i++) {
      await t.pump(const Duration(milliseconds: 20));
    }
  }

  Future<void> pumpApp(WidgetTester t) async {
    t.view.physicalSize = const Size(420, 900); // phone-sized, avoids test-only overflow
    t.view.devicePixelRatio = 1.0;
    addTearDown(t.view.reset);
    await t.pumpWidget(ProviderScope(
      overrides: [
        pinServiceProvider.overrideWithValue(pins),
        appLockClockProvider.overrideWithValue(() => clock),
      ],
      child: MaterialApp(
        navigatorKey: navKey,
        builder: (context, child) => AppLockLayer(child: child!),
        home: const Scaffold(body: Text(secret)),
      ),
    ));
    await flush(t);
  }

  Future<void> typePin(WidgetTester t, String pin) async {
    for (final d in pin.split('')) {
      await t.tap(find.text(d));
      await t.pump();
    }
    await flush(t);
  }

  Future<void> goBackground(WidgetTester t, Duration away) async {
    t.binding.handleAppLifecycleStateChanged(AppLifecycleState.inactive);
    t.binding.handleAppLifecycleStateChanged(AppLifecycleState.hidden);
    t.binding.handleAppLifecycleStateChanged(AppLifecycleState.paused);
    await flush(t);
    clock = clock.add(away);
  }

  Future<void> comeBack(WidgetTester t) async {
    t.binding.handleAppLifecycleStateChanged(AppLifecycleState.hidden);
    t.binding.handleAppLifecycleStateChanged(AppLifecycleState.inactive);
    t.binding.handleAppLifecycleStateChanged(AppLifecycleState.resumed);
    await flush(t);
  }

  testWidgets('no PIN set: app opens normally, nothing is locked', (t) async {
    await boot();
    await pumpApp(t);
    expect(find.text(secret), findsOneWidget);
    expect(find.text(pinPrompt), findsNothing);
  });

  testWidgets('cold start with a PIN: PIN screen shown, financial screen NOT visible', (t) async {
    await boot(setPin: '1234');
    await pumpApp(t);
    expect(find.text(pinPrompt), findsOneWidget);
    expect(find.text(secret), findsNothing); // Offstage content is not found
  });

  testWidgets('wrong PIN keeps it locked; right PIN unlocks', (t) async {
    await boot(setPin: '1234');
    await pumpApp(t);

    await typePin(t, '9999');
    expect(find.text('❌ ভুল PIN! আবার চেষ্টা করো'), findsOneWidget);
    expect(find.text(secret), findsNothing);

    await typePin(t, '1234');
    expect(find.text(secret), findsOneWidget);
    expect(find.text(pinPrompt), findsNothing);
  });

  testWidgets('1 minute timeout: 29s away stays unlocked, 61s away locks', (t) async {
    await boot(setPin: '1234', timeout: LockTimeout.minute1);
    await pumpApp(t);
    await typePin(t, '1234');
    expect(find.text(secret), findsOneWidget);

    await goBackground(t, const Duration(seconds: 29));
    expect(find.text(secret), findsNothing); // hidden while in background
    await comeBack(t);
    expect(find.text(secret), findsOneWidget);
    expect(find.text(pinPrompt), findsNothing);

    await goBackground(t, const Duration(seconds: 61));
    await comeBack(t);
    expect(find.text(pinPrompt), findsOneWidget);
    expect(find.text(secret), findsNothing);

    await typePin(t, '1234');
    expect(find.text(secret), findsOneWidget);
  });

  testWidgets('immediately: leaving and returning requires the PIN', (t) async {
    await boot(setPin: '1234', timeout: LockTimeout.immediately);
    await pumpApp(t);
    await typePin(t, '1234');

    await goBackground(t, Duration.zero);
    await comeBack(t);
    expect(find.text(pinPrompt), findsOneWidget);
    expect(find.text(secret), findsNothing);
  });

  testWidgets('never: returning from a long background trip does not lock', (t) async {
    await boot(setPin: '1234', timeout: LockTimeout.never);
    await pumpApp(t);
    await typePin(t, '1234');

    await goBackground(t, const Duration(hours: 5));
    await comeBack(t);
    expect(find.text(secret), findsOneWidget);
    expect(find.text(pinPrompt), findsNothing);
  });

  testWidgets('content is hidden (privacy cover) while the app is not in the foreground', (t) async {
    await boot(setPin: '1234', timeout: LockTimeout.never);
    await pumpApp(t);
    await typePin(t, '1234');

    t.binding.handleAppLifecycleStateChanged(AppLifecycleState.inactive);
    await flush(t);
    expect(find.text(secret), findsNothing);
    expect(find.byIcon(Icons.lock_rounded), findsOneWidget);

    t.binding.handleAppLifecycleStateChanged(AppLifecycleState.resumed);
    await flush(t);
    expect(find.text(secret), findsOneWidget);
  });

  testWidgets('screens pushed on the Navigator are covered too, and state survives unlock', (t) async {
    await boot(setPin: '1234', timeout: LockTimeout.immediately);
    await pumpApp(t);
    await typePin(t, '1234');

    navKey.currentState!.push(MaterialPageRoute<void>(
        builder: (_) => const Scaffold(body: Text(pushed))));
    await flush(t);
    expect(find.text(pushed), findsOneWidget);

    await goBackground(t, Duration.zero);
    await comeBack(t);
    expect(find.text(pinPrompt), findsOneWidget);
    expect(find.text(pushed), findsNothing);
    expect(find.text(secret), findsNothing);

    await typePin(t, '1234');
    expect(find.text(pushed), findsOneWidget); // same screen, nothing lost
  });

  testWidgets('legacy plain-text PIN: user is not locked out, and it is migrated at startup', (t) async {
    await boot(prefs: {'pin_enabled': true, 'app_pin': '2468'});
    await pumpApp(t);

    // eager migration already moved it to the secret store
    expect((await SharedPreferences.getInstance()).getString('app_pin'), isNull);
    expect(store.data.containsKey(PinService.secretKey), true);

    expect(find.text(pinPrompt), findsOneWidget);
    await typePin(t, '2468');
    expect(find.text(secret), findsOneWidget);
  });

  testWidgets('legacy PIN + failing secure storage: old PIN still unlocks', (t) async {
    await boot(prefs: {'pin_enabled': true, 'app_pin': '2468'});
    store.failWrites = true;
    await pumpApp(t);
    await typePin(t, '2468');
    expect(find.text(secret), findsOneWidget);
    expect((await SharedPreferences.getInstance()).getString('app_pin'), '2468');
  });

  testWidgets('lock on but credential gone: user is told and the lock is switched off', (t) async {
    await boot(prefs: {'pin_enabled': true});
    await pumpApp(t);
    expect(find.text(pinPrompt), findsOneWidget);

    await typePin(t, '1111');
    expect(find.text(secret), findsOneWidget);
    expect(find.textContaining('লক বন্ধ করা হয়েছে'), findsOneWidget);
    expect(await pins.isEnabled(), false);
  });

  testWidgets('after 5 wrong PINs input is blocked, even the right PIN is refused', (t) async {
    await boot(setPin: '1234');
    await pumpApp(t);
    for (var i = 0; i < 5; i++) {
      await typePin(t, '0000');
    }
    expect(find.textContaining('সেকেন্ড পরে চেষ্টা করো'), findsOneWidget);

    await typePin(t, '1234');
    expect(find.text(secret), findsNothing);

    await t.pumpWidget(const SizedBox()); // dispose so the countdown timer is cancelled
  });

  group('settings unreadable (fail closed)', () {
    const unavailableTitle = 'নিরাপত্তা সেটিং পড়া যাচ্ছে না';
    const retryLabel = 'আবার চেষ্টা করুন';

    testWidgets('PIN really enabled but settings unreadable: app stays locked, then PIN screen after retry', (t) async {
      await boot(setPin: '1234');
      final flaky = FlakyPinService(store: store, now: () => clock, iterations: 2)
        ..failEnabledRead = true;
      pins = flaky;
      await pumpApp(t);

      expect(find.text(secret), findsNothing); // financial UI is not exposed
      expect(find.text(unavailableTitle), findsOneWidget);
      expect(find.text(pinPrompt), findsNothing);

      flaky.failEnabledRead = false; // the failure was transient
      await t.tap(find.text(retryLabel));
      await flush(t);

      expect(find.text(unavailableTitle), findsNothing);
      expect(find.text(pinPrompt), findsOneWidget); // PIN is enabled -> normal PIN screen
      expect(find.text(secret), findsNothing);
      await typePin(t, '1234');
      expect(find.text(secret), findsOneWidget);
    });

    testWidgets('no PIN configured but settings unreadable: still locked (unknown is not "disabled"), opens after retry', (t) async {
      await boot();
      final flaky = FlakyPinService(store: store, now: () => clock, iterations: 2)
        ..failEnabledRead = true;
      pins = flaky;
      await pumpApp(t);
      expect(find.text(secret), findsNothing);
      expect(find.text(unavailableTitle), findsOneWidget);

      flaky.failEnabledRead = false;
      await t.tap(find.text(retryLabel));
      await flush(t);
      expect(find.text(unavailableTitle), findsNothing);
      expect(find.text(secret), findsOneWidget);
    });

    testWidgets('while the failure persists, a background trip and return cannot get past it', (t) async {
      await boot();
      final flaky = FlakyPinService(store: store, now: () => clock, iterations: 2)
        ..failEnabledRead = true;
      pins = flaky;
      await pumpApp(t);

      await goBackground(t, const Duration(hours: 1));
      await comeBack(t); // automatic retry fails again
      expect(find.text(secret), findsNothing);
      expect(find.text(unavailableTitle), findsOneWidget);
    });

    testWidgets('a transient failure recovers automatically when the app returns to the foreground', (t) async {
      await boot();
      final flaky = FlakyPinService(store: store, now: () => clock, iterations: 2)
        ..failEnabledRead = true;
      pins = flaky;
      await pumpApp(t);
      expect(find.text(unavailableTitle), findsOneWidget);

      flaky.failEnabledRead = false;
      await goBackground(t, Duration.zero);
      await comeBack(t);
      expect(find.text(unavailableTitle), findsNothing);
      expect(find.text(secret), findsOneWidget);
    });

    testWidgets('settings becoming unreadable while the app is open locks it', (t) async {
      await boot();
      final flaky = FlakyPinService(store: store, now: () => clock, iterations: 2);
      pins = flaky;
      await pumpApp(t);
      expect(find.text(secret), findsOneWidget); // normal: PIN disabled, app open

      flaky.failEnabledRead = true;
      final container = ProviderScope.containerOf(t.element(find.byType(AppLockLayer)));
      await container.read(lockSettingsProvider.notifier).reload();
      await flush(t);

      expect(find.text(secret), findsNothing);
      expect(find.text(unavailableTitle), findsOneWidget);
    });
  });
}
