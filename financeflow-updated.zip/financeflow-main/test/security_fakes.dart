import 'package:financeflow/data/security/lock_timeout.dart';
import 'package:financeflow/data/security/pin_service.dart';
import 'package:financeflow/data/security/secret_store.dart';

/// In-memory stand-in for the Keystore-backed store, with failure injection.
class FakeSecretStore implements SecretStore {
  final Map<String, String> data = {};
  bool failReads = false;
  bool failWrites = false;

  /// Lets a test make read() return something different from what was written
  /// (simulates a store that silently corrupts data).
  String? Function(String? stored)? corruptOnRead;

  @override
  Future<String?> read(String key) async {
    if (failReads) throw StateError('read failed');
    final v = data[key];
    return corruptOnRead != null ? corruptOnRead!(v) : v;
  }

  @override
  Future<void> write(String key, String value) async {
    if (failWrites) throw StateError('write failed');
    data[key] = value;
  }

  @override
  Future<void> delete(String key) async {
    data.remove(key);
  }
}

/// PinService whose SETTINGS reads (SharedPreferences) can be made to fail,
/// simulating unreadable security state.
class FlakyPinService extends PinService {
  FlakyPinService({super.store, super.now, super.iterations});

  bool failEnabledRead = false;
  bool failTimeoutRead = false;

  @override
  Future<bool> isEnabled() async {
    if (failEnabledRead) throw StateError('preferences unreadable');
    return super.isEnabled();
  }

  @override
  Future<LockTimeout> loadTimeout() async {
    if (failTimeoutRead) throw StateError('preferences unreadable');
    return super.loadTimeout();
  }
}
