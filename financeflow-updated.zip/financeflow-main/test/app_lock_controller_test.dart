import 'package:flutter_test/flutter_test.dart';
import 'package:financeflow/data/security/app_lock_controller.dart';
import 'package:financeflow/data/security/lock_timeout.dart';

void main() {
  late DateTime now;
  late AppLockController c;

  setUp(() {
    now = DateTime(2026, 9, 30, 12);
    c = AppLockController(now: () => now);
  });

  void started(LockTimeout t, {bool pin = true}) {
    c.start(pinEnabled: pin, timeout: t);
    c.unlock(); // user entered the PIN after launch
  }

  bool leaveAndReturn(Duration away) {
    c.onBackground();
    now = now.add(away);
    return c.onForeground();
  }

  group('cold start', () {
    test('PIN on -> locked (original behaviour)', () {
      c.start(pinEnabled: true, timeout: LockTimeout.never);
      expect(c.locked, true);
    });
    test('PIN off -> not locked', () {
      c.start(pinEnabled: false, timeout: LockTimeout.minute1);
      expect(c.locked, false);
    });
  });

  group('timeouts', () {
    test('never: staying away for a day does not lock', () {
      started(LockTimeout.never);
      expect(leaveAndReturn(const Duration(days: 1)), false);
    });

    test('immediately: any background trip locks', () {
      started(LockTimeout.immediately);
      expect(leaveAndReturn(Duration.zero), true);
    });

    test('30 seconds: 29s no, 30s yes', () {
      started(LockTimeout.seconds30);
      expect(leaveAndReturn(const Duration(seconds: 29)), false);
      expect(leaveAndReturn(const Duration(seconds: 30)), true);
    });

    test('1 minute: 59s no, 60s yes', () {
      started(LockTimeout.minute1);
      expect(leaveAndReturn(const Duration(seconds: 59)), false);
      expect(leaveAndReturn(const Duration(seconds: 60)), true);
    });

    test('5 minutes: 4m59s no, 5m yes', () {
      started(LockTimeout.minutes5);
      expect(leaveAndReturn(const Duration(minutes: 4, seconds: 59)), false);
      expect(leaveAndReturn(const Duration(minutes: 5)), true);
    });
  });

  group('lifecycle details', () {
    test('a brief "inactive" with no background trip never locks', () {
      started(LockTimeout.immediately);
      // inactive -> resumed: the widget only calls onForeground()
      expect(c.onForeground(), false);
    });

    test('repeated onBackground (hidden then paused) keeps the FIRST timestamp', () {
      started(LockTimeout.seconds30);
      c.onBackground();
      now = now.add(const Duration(seconds: 20));
      c.onBackground(); // paused arrives after hidden
      now = now.add(const Duration(seconds: 11));
      expect(c.onForeground(), true); // 31s since the first, not 11s
    });

    test('clock set backwards while away -> locks (fail safe)', () {
      started(LockTimeout.minutes5);
      c.onBackground();
      now = now.subtract(const Duration(hours: 2));
      expect(c.onForeground(), true);
    });

    test('stays locked until unlock()', () {
      started(LockTimeout.immediately);
      expect(leaveAndReturn(Duration.zero), true);
      expect(c.onForeground(), true);
      c.unlock();
      expect(c.locked, false);
    });

    test('unlock resets the timer: next trip is measured from the new departure', () {
      started(LockTimeout.seconds30);
      expect(leaveAndReturn(const Duration(seconds: 45)), true);
      c.unlock();
      expect(leaveAndReturn(const Duration(seconds: 10)), false);
    });

    test('no PIN -> background trips never lock', () {
      started(LockTimeout.immediately, pin: false);
      expect(leaveAndReturn(const Duration(hours: 1)), false);
    });

    test('PIN turned off while the app is in the background -> no lock on return', () {
      started(LockTimeout.immediately);
      c.onBackground();
      c.updateSettings(pinEnabled: false);
      expect(c.onForeground(), false);
    });

    test('PIN turned ON during the session does not lock immediately', () {
      c.start(pinEnabled: false, timeout: LockTimeout.minute1);
      c.updateSettings(pinEnabled: true);
      expect(c.locked, false);
    });

    test('timeout changed while away uses the new value on return', () {
      started(LockTimeout.minutes5);
      c.onBackground();
      now = now.add(const Duration(seconds: 40));
      c.updateSettings(timeout: LockTimeout.seconds30);
      expect(c.onForeground(), true);
    });
  });

  group('settings unavailable (fail closed)', () {
    test('normal start is unchanged: PIN on -> locked, PIN off -> not locked', () {
      c.start(pinEnabled: true, timeout: LockTimeout.never);
      expect(c.locked, true);
      expect(c.settingsUnavailable, false);
      c.start(pinEnabled: false, timeout: LockTimeout.never);
      expect(c.locked, false);
    });

    test('unreadable settings at start: locked even though no PIN is known', () {
      c.start(pinEnabled: false, timeout: LockTimeout.never, settingsUnavailable: true);
      expect(c.locked, true);
      expect(c.settingsUnavailable, true);
    });

    test('unlock() cannot open an unknown security state', () {
      c.start(pinEnabled: false, timeout: LockTimeout.never, settingsUnavailable: true);
      c.unlock();
      expect(c.locked, true);
    });

    test('a background trip does not unlock it (even with timeout never / PIN flag false)', () {
      c.start(pinEnabled: false, timeout: LockTimeout.never, settingsUnavailable: true);
      c.onBackground();
      now = now.add(const Duration(hours: 1));
      expect(c.onForeground(), true);
      expect(c.locked, true);
    });

    test('settings becoming unreadable while the app is open locks it at once', () {
      started(LockTimeout.minute1);
      expect(c.locked, false);
      c.updateSettings(settingsUnavailable: true);
      expect(c.locked, true);
      expect(c.settingsUnavailable, true);
    });

    test('recovery with PIN disabled opens the app', () {
      c.start(pinEnabled: false, timeout: LockTimeout.never, settingsUnavailable: true);
      c.updateSettings(pinEnabled: false, timeout: LockTimeout.never, settingsUnavailable: false);
      expect(c.settingsUnavailable, false);
      expect(c.locked, false);
    });

    test('recovery with PIN enabled keeps the app locked (cold-start behaviour); the PIN then unlocks', () {
      c.start(pinEnabled: false, timeout: LockTimeout.never, settingsUnavailable: true);
      c.updateSettings(pinEnabled: true, timeout: LockTimeout.minute1, settingsUnavailable: false);
      expect(c.settingsUnavailable, false);
      expect(c.locked, true);
      c.unlock();
      expect(c.locked, false);
    });
  });
}
