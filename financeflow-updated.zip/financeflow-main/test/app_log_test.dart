import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:financeflow/core/app_log.dart';

void main() {
  group('describeError', () {
    test('keeps the plugin error code and the Google status code', () {
      final d = describeError(PlatformException(
        code: 'sign_in_failed',
        message: 'com.google.android.gms.common.api.ApiException: 10: ',
      ));
      expect(d, contains('PlatformException'));
      expect(d, contains('code=sign_in_failed'));
      expect(d, contains('ApiException: 10'));
    });

    test('removes e-mail addresses from the message', () {
      final d = describeError(PlatformException(
          code: 'x', message: 'failed for first.last+x@example.co.uk now'));
      expect(d, isNot(contains('@')));
      expect(d, contains('<email>'));
    });

    test('removes token-like strings (OAuth access token and JWT shapes)', () {
      final a = describeError(PlatformException(
          code: 'x',
          message: 'bad token ya29.a0AfH6SMBxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx1234 end'));
      expect(a, isNot(contains('ya29')));
      expect(a, isNot(contains('AfH6')));
      final j = describeError(PlatformException(
          code: 'x',
          message: 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjEyMyJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.abcDEF123_-xyz'));
      expect(j, isNot(contains('eyJ')));
    });

    test('never includes the details field', () {
      final d = describeError(PlatformException(
          code: 'x',
          message: 'm',
          details: 'SECRET-DETAILS-0123456789012345678901234567890123456789'));
      expect(d, isNot(contains('SECRET')));
    });

    test('long messages are truncated', () {
      final d = describeError(
          PlatformException(code: 'x', message: List.filled(400, 'word').join(' ')));
      expect(d.length, lessThan(260));
    });

    test('null message adds no "message=" part', () {
      expect(describeError(PlatformException(code: 'sign_in_failed')),
          'PlatformException code=sign_in_failed');
    });

    test('other exceptions are reported by type only (their text is never used)', () {
      expect(describeError(const FormatException('contains user@example.com')),
          'FormatException');
    });
  });

  test('logDiagnostic prints the sanitised description with the operation name', () {
    final printed = <String>[];
    final original = debugPrint;
    debugPrint = (String? message, {int? wrapWidth}) => printed.add(message ?? '');
    addTearDown(() => debugPrint = original);

    logDiagnostic(
        'signIn',
        PlatformException(
            code: 'sign_in_failed',
            message: 'ApiException: 10: for user@example.com'));

    expect(printed, hasLength(1));
    expect(printed.single, startsWith('[FinanceFlow] signIn: PlatformException code=sign_in_failed'));
    expect(printed.single, isNot(contains('@')));
  });
}
