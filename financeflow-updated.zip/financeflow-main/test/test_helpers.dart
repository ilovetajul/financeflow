// sqflite re-exports its own `Transaction` class; hide it so the name below
// always means the FinanceFlow domain model.
import 'package:sqflite_common_ffi/sqflite_ffi.dart' hide Transaction;
import 'package:financeflow/data/local/database_helper.dart';
import 'package:financeflow/domain/models/debt_model.dart';
import 'package:financeflow/domain/models/transaction.dart';

void initFfi() {
  sqfliteFfiInit();
  databaseFactory = databaseFactoryFfi;
}

/// Fresh in-memory v2 database installed as the DatabaseHelper singleton.
Future<DatabaseHelper> openTestDb() async {
  final db = await DatabaseHelper.openAtPath(inMemoryDatabasePath);
  DatabaseHelper.useDatabaseForTesting(db);
  return DatabaseHelper.instance;
}

Transaction tx(String id,
        {TransactionType type = TransactionType.expense,
        double amount = 100,
        String date = '2026-09-30T20:15:00.000',
        String? sourceId}) =>
    Transaction(
      id: id,
      type: type,
      category: 'খাবার',
      amount: amount,
      note: 'note $id',
      date: DateTime.parse(date),
      icon: '🍜',
      sourceId: sourceId,
    );

DebtPerson person(String id, [String name = 'Rahim']) =>
    DebtPerson(id: id, name: name, phone: '017');

DebtTransaction dtx(String id, String personId, DebtType type, double amount,
        [String date = '2026-09-30T10:00:00.000']) =>
    DebtTransaction(
      id: id,
      personId: personId,
      amount: amount,
      type: type,
      date: DateTime.parse(date),
      note: 'd $id',
    );
