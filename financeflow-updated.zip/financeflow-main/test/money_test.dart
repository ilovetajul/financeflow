import 'package:flutter_test/flutter_test.dart';
import 'package:financeflow/core/money.dart';

void main() {
  group('Money.parse', () {
    test('accepts plain, decimal, grouped and Bengali-digit input', () {
      expect(Money.parse('100').value, 100);
      expect(Money.parse('100.50').value, 100.5);
      expect(Money.parse('1,250.75').value, 1250.75);
      expect(Money.parse('৳১২৫০').value, 1250);
      expect(Money.parse(' 5 ').value, 5);
    });

    test('rejects empty / null', () {
      expect(Money.parse('').error, Money.errEmpty);
      expect(Money.parse('   ').error, Money.errEmpty);
      expect(Money.parse(null).error, Money.errEmpty);
    });

    test('rejects invalid characters, exponent, NaN, Infinity', () {
      for (final s in ['abc', '12a', '1e5', 'NaN', 'Infinity', '1.2.3', '--5', '١٢٣x']) {
        expect(Money.parse(s).isValid, false, reason: s);
      }
    });

    test('rejects zero and negatives', () {
      expect(Money.parse('0').error, Money.errZero);
      expect(Money.parse('0.00').error, Money.errZero);
      expect(Money.parse('-5').error, Money.errNegative);
      expect(Money.parse('0', allowZero: true).value, 0);
    });

    test('rejects extremely large values', () {
      expect(Money.parse('1000000000').error, Money.errTooLarge);
      expect(Money.parse('999999999.99').value, 999999999.99);
    });

    test('rounds to 2 decimals', () {
      expect(Money.parse('10.006').value, 10.01);
      expect(Money.parse('10.004').value, 10.0);
      expect(Money.parse('0.1').value, 0.1);
    });
  });

  group('Money.format (Bangladeshi grouping, display only)', () {
    test('groups lakh/crore', () {
      expect(Money.format(0), '৳0');
      expect(Money.format(999), '৳999');
      expect(Money.format(1000), '৳1,000');
      expect(Money.format(10000), '৳10,000');
      expect(Money.format(100000), '৳1,00,000');
      expect(Money.format(1000000), '৳10,00,000');
      expect(Money.format(12345678), '৳1,23,45,678');
    });
    test('decimals, negatives, no symbol', () {
      expect(Money.format(1250.5), '৳1,250.50');
      expect(Money.format(-4000), '-৳4,000');
      expect(Money.format(1000, symbol: false), '1,000');
    });
  });

  test('toInputText keeps decimals', () {
    expect(Money.toInputText(500), '500');
    expect(Money.toInputText(100.5), '100.5');
    expect(Money.toInputText(100.55), '100.55');
  });
}
