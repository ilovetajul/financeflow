import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:financeflow/data/security/lock_timeout.dart';
import 'package:financeflow/data/security/pin_service.dart';
import 'security_fakes.dart';

String hex(List<int> b) => b.map((x) => x.toRadixString(16).padLeft(2, '0')).join();

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late FakeSecretStore store;
  late DateTime clock;
  late PinService svc;

  PinService build() =>
      PinService(store: store, now: () => clock, iterations: 3); // fast in tests

  Future<void> boot([Map<String, Object> prefs = const {}]) async {
    SharedPreferences.setMockInitialValues(prefs);
    store = FakeSecretStore();
    clock = DateTime(2026, 9, 30, 12);
    svc = build();
  }

  Future<SharedPreferences> prefs() => SharedPreferences.getInstance();

  group('PBKDF2-HMAC-SHA256', () {
    // Vectors cross-checked against Python hashlib.pbkdf2_hmac.
    test('known vectors', () {
      final pw = utf8.encode('password'), salt = utf8.encode('salt');
      expect(hex(pbkdf2Sha256(pw, salt, 1)),
          '120fb6cffcf8b32c43e7225256c4f837a86548c92ccc35480805987cb70be17b');
      expect(hex(pbkdf2Sha256(pw, salt, 2)),
          'ae4d0c95af6b46d32d0adff928f06dd02a303f8ef3c251dfd6e2d85a95474c43');
      expect(hex(pbkdf2Sha256(pw, salt, 4096)),
          'c5e478d59288c841aa530db6845c4c8d962893a001ce4e11a4963873aa98134a');
    });
  });

  group('secure storage of a new PIN', () {
    setUp(() => boot());

    test('stores only a salted hash in the secret store; no plain PIN anywhere', () async {
      await svc.setPin('4821');
      final p = await prefs();

      expect(p.getBool('pin_enabled'), true);
      expect(p.getString('app_pin'), isNull);
      for (final k in p.getKeys()) {
        expect(p.get(k).toString(), isNot(contains('4821')), reason: k);
      }
      final raw = store.data[PinService.secretKey]!;
      final j = jsonDecode(raw) as Map<String, dynamic>;
      expect(j.keys.toSet(), {'v', 'iter', 'salt', 'hash'});
      expect(raw, isNot(contains('4821')));
    });

    test('two PINs / same PIN twice get different salts and hashes', () async {
      await svc.setPin('1234');
      final a = store.data[PinService.secretKey];
      await svc.setPin('1234');
      final b = store.data[PinService.secretKey];
      expect(a, isNot(b));
    });

    test('verify: right PIN ok, wrong PIN rejected', () async {
      await svc.setPin('1234');
      expect((await svc.verify('1234')).outcome, PinOutcome.ok);
      expect((await svc.verify('1235')).outcome, PinOutcome.wrong);
    });

    test('rejects anything that is not exactly 4 digits', () async {
      for (final bad in ['123', '12345', 'abcd', '12 4', '']) {
        await expectLater(svc.setPin(bad), throwsA(isA<PinException>()), reason: bad);
      }
      expect(await svc.isEnabled(), false);
    });

    test('if the secure write fails the lock is NOT enabled and state is unchanged', () async {
      store.failWrites = true;
      await expectLater(svc.setPin('1234'), throwsA(isA<PinException>()));
      expect(await svc.isEnabled(), false);
      expect(store.data, isEmpty);
    });

    test('if the stored value reads back wrong the lock is NOT enabled', () async {
      store.corruptOnRead = (_) => 'garbage';
      await expectLater(svc.setPin('1234'), throwsA(isA<PinException>()));
      expect(await svc.isEnabled(), false);
    });

    test('new PIN gets a 1-minute default timeout; an existing choice is kept', () async {
      await svc.setPin('1234');
      expect(await svc.loadTimeout(), LockTimeout.minute1);

      await svc.saveTimeout(LockTimeout.minutes5);
      await svc.disable();
      await svc.setPin('1234');
      expect(await svc.loadTimeout(), LockTimeout.minutes5);
    });

    test('disable removes the hash and turns the flag off', () async {
      await svc.setPin('1234');
      await svc.disable();
      expect(await svc.isEnabled(), false);
      expect(store.data, isEmpty);
    });
  });

  group('migration from the old plain-text PIN', () {
    Map<String, Object> legacy([String pin = '2468']) =>
        {'pin_enabled': true, 'app_pin': pin};

    test('eager migration: hashed, verified, plain copy removed, same PIN still works', () async {
      await boot(legacy());
      expect(await svc.migrateLegacyIfNeeded(), LegacyMigration.migrated);

      final p = await prefs();
      expect(p.getString('app_pin'), isNull);
      expect(p.getBool('pin_enabled'), true);
      expect(store.data.containsKey(PinService.secretKey), true);
      expect((await svc.verify('2468')).outcome, PinOutcome.ok);
      expect((await svc.verify('0000')).outcome, PinOutcome.wrong);
    });

    test('is idempotent', () async {
      await boot(legacy());
      await svc.migrateLegacyIfNeeded();
      final before = store.data[PinService.secretKey];
      expect(await svc.migrateLegacyIfNeeded(), LegacyMigration.none);
      expect(store.data[PinService.secretKey], before);
      expect((await svc.verify('2468')).outcome, PinOutcome.ok);
    });

    test('NO LOCK-OUT: secure write fails -> deferred, plain PIN kept and still works', () async {
      await boot(legacy());
      store.failWrites = true;
      expect(await svc.migrateLegacyIfNeeded(), LegacyMigration.deferred);

      final p = await prefs();
      expect(p.getString('app_pin'), '2468'); // never deleted before verification
      expect((await svc.verify('2468')).outcome, PinOutcome.ok);
      expect((await svc.verify('1111')).outcome, PinOutcome.wrong);
    });

    test('NO LOCK-OUT: secure read fails -> deferred, plain PIN still works', () async {
      await boot(legacy());
      store.failReads = true;
      expect(await svc.migrateLegacyIfNeeded(), LegacyMigration.deferred);
      expect((await svc.verify('2468')).outcome, PinOutcome.ok);
      expect((await prefs()).getString('app_pin'), '2468');
    });

    test('NO LOCK-OUT: store returns corrupted data -> deferred, plain PIN kept', () async {
      await boot(legacy());
      store.corruptOnRead = (_) => 'garbage';
      expect(await svc.migrateLegacyIfNeeded(), LegacyMigration.deferred);
      expect((await prefs()).getString('app_pin'), '2468');
      expect((await svc.verify('2468')).outcome, PinOutcome.ok);
    });

    test('deferred migration completes later (lazily, after a successful unlock)', () async {
      await boot(legacy());
      store.failWrites = true;
      await svc.migrateLegacyIfNeeded();
      expect((await prefs()).getString('app_pin'), '2468');

      store.failWrites = false; // storage recovers
      expect((await svc.verify('2468')).outcome, PinOutcome.ok);
      expect((await prefs()).getString('app_pin'), isNull);
      expect(store.data.containsKey(PinService.secretKey), true);
      expect((await svc.verify('2468')).outcome, PinOutcome.ok);
    });

    test('lazy migration also works when the app never ran the eager step', () async {
      await boot(legacy());
      expect((await svc.verify('2468')).outcome, PinOutcome.ok);
      expect((await prefs()).getString('app_pin'), isNull);
    });

    test('interrupted migration (hash written, plain not yet removed) is cleaned up', () async {
      await boot(legacy());
      store.failWrites = false;
      // simulate: hash written by an earlier run, plain copy still there
      final other = PinService(store: store, iterations: 3);
      await other.migrateLegacyIfNeeded(); // writes hash + removes plain
      (await prefs()).setString('app_pin', '2468'); // put the plain copy back
      expect(await svc.migrateLegacyIfNeeded(), LegacyMigration.migrated);
      expect((await prefs()).getString('app_pin'), isNull);
      expect((await svc.verify('2468')).outcome, PinOutcome.ok);
    });

    test('hash and plain PIN disagree: both kept and the old PIN is still accepted (no lock-out)', () async {
      await boot(legacy('2468'));
      await svc.setPin('1357'); // creates a hash for a different PIN
      (await prefs()).setString('app_pin', '2468'); // anomalous leftover
      expect(await svc.migrateLegacyIfNeeded(), LegacyMigration.deferred);
      expect((await prefs()).getString('app_pin'), '2468'); // not deleted
      expect((await svc.verify('2468')).outcome, PinOutcome.ok);
    });

    test('hash and plain PIN disagree: the hashed PIN is accepted too', () async {
      await boot(legacy('2468'));
      await svc.setPin('1357');
      (await prefs()).setString('app_pin', '2468');
      expect((await svc.verify('1357')).outcome, PinOutcome.ok);
    });

    test('lock was off: leftover plain PIN is removed', () async {
      await boot({'pin_enabled': false, 'app_pin': '2468'});
      expect(await svc.migrateLegacyIfNeeded(), LegacyMigration.removedStale);
      expect((await prefs()).getString('app_pin'), isNull);
    });

    test('nothing to migrate for users without a PIN', () async {
      await boot();
      expect(await svc.migrateLegacyIfNeeded(), LegacyMigration.none);
    });

    test('existing timeout preference is untouched; missing one means "never" (old behaviour)', () async {
      await boot(legacy());
      await svc.migrateLegacyIfNeeded();
      expect(await svc.loadTimeout(), LockTimeout.never);
    });
  });

  group('wrong-attempt throttling', () {
    setUp(() async {
      await boot();
      await svc.setPin('1234');
    });

    test('5th wrong attempt starts a 30s delay; correct PIN is refused during it', () async {
      for (var i = 0; i < 4; i++) {
        final r = await svc.verify('0000');
        expect(r.outcome, PinOutcome.wrong);
        expect(r.blockedFor, isNull);
      }
      final fifth = await svc.verify('0000');
      expect(fifth.outcome, PinOutcome.wrong);
      expect(fifth.blockedFor, const Duration(seconds: 30));

      final during = await svc.verify('1234');
      expect(during.outcome, PinOutcome.throttled);

      clock = clock.add(const Duration(seconds: 31));
      expect((await svc.verify('1234')).outcome, PinOutcome.ok);
    });

    test('delay doubles and success resets the counter', () async {
      for (var i = 0; i < 5; i++) { await svc.verify('0000'); }
      clock = clock.add(const Duration(seconds: 31));
      final sixth = await svc.verify('0000');
      expect(sixth.blockedFor, const Duration(seconds: 60));

      clock = clock.add(const Duration(seconds: 61));
      expect((await svc.verify('1234')).outcome, PinOutcome.ok);
      final after = await svc.verify('0000');
      expect(after.outcome, PinOutcome.wrong);
      expect(after.blockedFor, isNull); // counter was reset
    });

    test('delay is capped at 5 minutes', () async {
      for (var i = 0; i < 20; i++) {
        clock = clock.add(const Duration(minutes: 10));
        await svc.verify('0000');
      }
      clock = clock.add(const Duration(minutes: 10));
      final r = await svc.verify('0000');
      expect(r.blockedFor, const Duration(minutes: 5));
    });

    test('throttle survives an app restart (persisted, not in memory)', () async {
      for (var i = 0; i < 5; i++) { await svc.verify('0000'); }
      final restarted = build(); // new service instance, same prefs
      expect((await restarted.verify('1234')).outcome, PinOutcome.throttled);
    });
  });

  group('broken / missing credential', () {
    test('lock on but no credential anywhere -> credentialMissing (not a silent lock-out)', () async {
      await boot({'pin_enabled': true});
      expect((await svc.verify('1234')).outcome, PinOutcome.credentialMissing);
    });

    test('corrupt hash record is treated as missing', () async {
      await boot({'pin_enabled': true});
      store.data[PinService.secretKey] = '{not json';
      expect((await svc.verify('1234')).outcome, PinOutcome.credentialMissing);
    });

    test('secure store unreadable and no legacy PIN -> unavailable (retry, never a bypass)', () async {
      await boot();
      await svc.setPin('1234');
      store.failReads = true;
      final r = await svc.verify('1234');
      expect(r.outcome, PinOutcome.unavailable);
      expect(await svc.isEnabled(), true); // lock stays on
    });

    test('resetBrokenLock turns the lock off', () async {
      await boot({'pin_enabled': true});
      await svc.resetBrokenLock();
      expect(await svc.isEnabled(), false);
    });
  });

  group('lock timeout setting', () {
    setUp(() => boot());
    test('defaults to never when unset (preserves the old behaviour)', () async {
      expect(await svc.loadTimeout(), LockTimeout.never);
    });
    test('round-trips every option', () async {
      for (final t in LockTimeout.values) {
        await svc.saveTimeout(t);
        expect(await svc.loadTimeout(), t);
      }
    });
    test('an unknown stored value falls back to never', () async {
      (await prefs()).setInt('lock_timeout_seconds', 12345);
      expect(await svc.loadTimeout(), LockTimeout.never);
    });
    test('option values are 0 / 30 / 60 / 300 / -1 seconds', () {
      expect(LockTimeout.values.map((t) => t.seconds), [0, 30, 60, 300, -1]);
      expect(LockTimeout.never.duration, isNull);
      expect(LockTimeout.minute1.duration, const Duration(minutes: 1));
    });
  });
}
