import 'dart:convert';
import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:financeflow/data/backup/backup_service.dart';
import 'package:financeflow/data/local/database_helper.dart';
import 'package:financeflow/domain/models/debt_model.dart';
import 'package:financeflow/domain/models/transaction.dart';
import 'test_helpers.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUpAll(initFfi);

  late DatabaseHelper h;
  late Directory tmp;
  late BackupService svc;

  setUp(() async {
    SharedPreferences.setMockInitialValues({'user_name': 'Tajul', 'user_phone': '0170'});
    h = await openTestDb();
    tmp = Directory.systemTemp.createTempSync('ff_bk');
    svc = BackupService(helper: h, emergencyDir: () async => tmp);
  });
  tearDown(() async {
    await DatabaseHelper.resetForTesting();
    if (tmp.existsSync()) tmp.deleteSync(recursive: true);
  });

  Future<void> seed() async {
    await h.insertCategoryRow({'id': 'c1', 'name': 'খাবার', 'icon': '🍜', 'type': 'expense'});
    await h.insertTransaction(tx('t1', amount: 120.5));
    await h.insertTransaction(tx('t2', type: TransactionType.income, amount: 5000));
    await h.insertPerson(person('p1'));
    await h.insertDebtTransaction(dtx('d1', 'p1', DebtType.gave, 5000),
        mirror: tx('m1', amount: 5000, sourceId: 'd1'));
    await h.insertDebtTransaction(dtx('d2', 'p1', DebtType.received, 1000));
  }

  group('create backup', () {
    test('contains transactions, categories, debt persons, debt transactions, settings',
        () async {
      await seed();
      final j = jsonDecode(await svc.buildBackupJson()) as Map<String, dynamic>;
      expect(j['backupVersion'], 2);
      expect(j['appName'], 'FinanceFlow');
      expect(j['appVersion'], isNotNull);
      expect((j['createdAt'] as String).endsWith('Z'), true); // unambiguous UTC
      expect((j['database']['transactions'] as List).length, 3);
      expect((j['database']['categories'] as List).length, 1);
      expect((j['debt']['persons'] as List).length, 1);
      expect((j['debt']['transactions'] as List).length, 2);
      expect(j['settings']['userName'], 'Tajul');
      expect(jsonEncode(j).contains('pin'), false); // no PIN material
    });

    test('file name is Android-safe and descriptive', () {
      expect(BackupService.fileName(DateTime(2026, 9, 30, 20, 15)),
          'FinanceFlow_Backup_2026-09-30_2015.json');
    });
  });

  group('PIN / security data is never part of a backup', () {
    test('backup JSON contains no PIN, hash or lock settings', () async {
      SharedPreferences.setMockInitialValues({
        'user_name': 'Tajul',
        'pin_enabled': true,
        'app_pin': '7391',
        'lock_timeout_seconds': 60,
        'pin_fail_count': 2,
      });
      await seed();
      final json = await svc.buildBackupJson();
      expect(json, isNot(contains('7391')));
      for (final k in ['app_pin', 'pin_enabled', 'pin_hash', 'lock_timeout', 'pin_fail']) {
        expect(json, isNot(contains(k)), reason: k);
      }
    });

    test('restoring a backup does not touch the PIN or lock settings', () async {
      SharedPreferences.setMockInitialValues({
        'pin_enabled': true, 'lock_timeout_seconds': 300, 'user_name': 'Old',
      });
      await seed();
      final parsed = svc.parse(await svc.buildBackupJson());
      await svc.restore(parsed, RestoreMode.replace);
      final p = await SharedPreferences.getInstance();
      expect(p.getBool('pin_enabled'), true);
      expect(p.getInt('lock_timeout_seconds'), 300);
    });
  });

  group('validation', () {
    Future<String> validJson() async {
      await seed();
      return svc.buildBackupJson();
    }

    void expectInvalid(String text) {
      expect(() => svc.parse(text),
          throwsA(isA<BackupException>().having((e) => e.userMessage, 'msg', Msg.invalid)));
    }

    test('valid backup parses', () async {
      final b = svc.parse(await validJson());
      expect(b.transactions.length, 3);
      expect(b.persons.length, 1);
      expect(b.includesDebt, true);
    });

    test('garbage / not JSON / wrong shape', () {
      expectInvalid('not json at all');
      expectInvalid('[]');
      expectInvalid('{}');
      expectInvalid('');
    });

    test('missing required collection', () async {
      final m = jsonDecode(await validJson()) as Map<String, dynamic>;
      (m['debt'] as Map).remove('transactions');
      expectInvalid(jsonEncode(m));
    });

    test('bad amount, bad date, bad type, duplicate id, dangling reference', () async {
      final text = await validJson(); // seed once
      Map<String, dynamic> base0() => jsonDecode(text) as Map<String, dynamic>;
      Future<Map<String, dynamic>> base() async => base0();

      var m = await base();
      m['database']['transactions'][0]['amount'] = 'abc';
      expectInvalid(jsonEncode(m));

      m = await base();
      m['database']['transactions'][0]['amount'] = -5;
      expectInvalid(jsonEncode(m));

      m = await base();
      m['database']['transactions'][0]['date'] = 'yesterday';
      expectInvalid(jsonEncode(m));

      m = await base();
      m['database']['transactions'][0]['type'] = 'transfer';
      expectInvalid(jsonEncode(m));

      m = await base();
      m['database']['transactions'][1]['id'] = m['database']['transactions'][0]['id'];
      expectInvalid(jsonEncode(m));

      m = await base();
      m['debt']['transactions'][0]['personId'] = 'nobody';
      expectInvalid(jsonEncode(m));
    });

    test('newer backup version is rejected with the dedicated message', () async {
      final m = jsonDecode(await validJson()) as Map<String, dynamic>;
      m['backupVersion'] = 3;
      expect(() => svc.parse(jsonEncode(m)),
          throwsA(isA<BackupException>().having((e) => e.userMessage, 'msg', Msg.newer)));
    });

    test('legacy (old app) backup is upgraded and has no debt section', () {
      final legacy = jsonEncode({
        'version': 2,
        'exportedAt': '2026-09-01T10:00:00.000',
        'transactions': [
          {'id': 'x', 'type': 'income', 'category': 'বেতন', 'amount': 10.0,
           'note': 'n', 'date': '2026-09-01T10:00:00.000', 'icon': '💼'}
        ],
        'categories': [
          {'id': 'i1', 'name': 'বেতন', 'icon': '💼', 'type': 'income'}
        ],
      });
      final b = svc.parse(legacy);
      expect(b.isLegacy, true);
      expect(b.includesDebt, false);
      expect(b.transactions.single['sourceId'], isNull);
    });
  });

  group('restore', () {
    test('replace: restores everything, writes a valid emergency backup of old data',
        () async {
      // backup of data set B
      await seed();
      final backupB = await svc.buildBackupJson();
      // current data = something else (A)
      await h.deleteDebtTransaction('d1');
      await h.deleteDebtTransaction('d2');
      await h.deletePersonCascade('p1');
      await h.insertTransaction(tx('onlyA', amount: 7));

      final parsed = svc.parse(backupB);
      final report = await svc.restore(parsed, RestoreMode.replace);

      expect((await h.getAllTransactions()).map((t) => t.id).toSet(), {'t1', 't2', 'm1'});
      expect((await h.getAllPersons()).length, 1);
      expect((await h.getAllDebtTransactions()).length, 2);
      expect((await h.getCategoryRows()).length, 1);
      expect(report.persons, 1);

      // emergency backup exists, is valid, and holds the PRE-restore data (A)
      final f = File(report.emergencyBackupPath);
      expect(f.existsSync(), true);
      final emergency = svc.parse(await f.readAsString());
      expect(emergency.transactions.map((e) => e['id']), contains('onlyA'));
    });

    test('dates survive backup -> restore unchanged (no timezone shift)', () async {
      await h.insertTransaction(tx('late', date: '2026-09-30T23:59:59.000'));
      await h.insertTransaction(tx('early', date: '2026-09-30T00:00:00.000'));
      final b = svc.parse(await svc.buildBackupJson());
      await svc.restore(b, RestoreMode.replace);
      final db = await h.database;
      final rows = await db.query('transactions', orderBy: 'id');
      expect(rows.map((r) => r['date']),
          ['2026-09-30T00:00:00.000', '2026-09-30T23:59:59.000']);
    });

    test('failed restore does not destroy current data (atomic rollback)', () async {
      await seed();
      final before = (await h.getAllTransactions()).length;

      // Bypass parse(): two rows share an id, so the insert fails midway.
      final broken = ParsedBackup(
        version: 2, isLegacy: false, appVersion: null, createdAt: null,
        transactions: [
          {'id': 'z', 'type': 'income', 'category': 'c', 'amount': 1.0, 'note': '',
           'date': '2026-01-01T00:00:00.000', 'icon': '', 'sourceId': null},
          {'id': 'z', 'type': 'income', 'category': 'c', 'amount': 2.0, 'note': '',
           'date': '2026-01-01T00:00:00.000', 'icon': '', 'sourceId': null},
        ],
        categories: const [], persons: const [], debtTransactions: const [],
        settings: const {}, includesCategories: true, includesDebt: true,
      );
      await expectLater(
          svc.restore(broken, RestoreMode.replace),
          throwsA(isA<BackupException>()
              .having((e) => e.userMessage, 'msg', Msg.restoreFailed)));

      expect((await h.getAllTransactions()).length, before);
      expect((await h.getAllPersons()).length, 1);
      expect((await h.getAllDebtTransactions()).length, 2);
      expect((await h.getCategoryRows()).length, 1);
    });

    test('restore is aborted (data untouched) if the emergency backup cannot be written',
        () async {
      await seed();
      final failing = BackupService(
          helper: h, emergencyDir: () async => throw const FileSystemException('disk'));
      final parsed = svc.parse(await svc.buildBackupJson());
      await expectLater(
          failing.restore(parsed, RestoreMode.replace),
          throwsA(isA<BackupException>()
              .having((e) => e.userMessage, 'msg', Msg.emergencyFailed)));
      expect((await h.getAllTransactions()).length, 3);
    });

    test('legacy restore replaces transactions but leaves debt data alone', () async {
      await seed();
      final legacy = svc.parse(jsonEncode({
        'version': 1,
        'transactions': [
          {'id': 'x', 'type': 'income', 'category': 'বেতন', 'amount': 10.0,
           'note': 'n', 'date': '2026-09-01T10:00:00.000', 'icon': '💼'}
        ],
      }));
      await svc.restore(legacy, RestoreMode.replace);
      expect((await h.getAllTransactions()).map((t) => t.id), ['x']);
      expect((await h.getAllPersons()).length, 1);
      expect((await h.getAllDebtTransactions()).length, 2);
      expect((await h.getCategoryRows()).length, 1); // legacy v1 had no categories
    });

    test('merge never duplicates and never deletes', () async {
      await seed();
      final parsed = svc.parse(await svc.buildBackupJson());
      await h.insertTransaction(tx('extra', amount: 1));

      final r1 = await svc.restore(parsed, RestoreMode.merge);
      expect(r1.transactions, 0);
      expect(r1.persons, 0);
      expect(r1.debtTransactions, 0);
      expect(r1.categories, 0);
      expect((await h.getAllTransactions()).length, 4); // 3 + extra, nothing lost
    });

    test('merge adds only the missing records', () async {
      await seed();
      final parsed = svc.parse(await svc.buildBackupJson());
      await h.deleteTransaction('t1');
      final r = await svc.restore(parsed, RestoreMode.merge);
      expect(r.transactions, 1);
      expect((await h.getAllTransactions()).length, 3);
    });
  });

  group('merge: ID conflicts', () {
    Future<String> snapshot() async {
      final db = await h.database;
      final out = <String, Object?>{};
      for (final t in ['transactions', 'categories', 'debt_persons', 'debt_transactions']) {
        out[t] = await db.query(t, orderBy: 'id');
      }
      return jsonEncode(out);
    }

    Future<ParsedBackup> backupOfSeed() async {
      await seed();
      return svc.parse(await svc.buildBackupJson());
    }

    Future<void> update(String table, Map<String, Object?> values, String id) async {
      final db = await h.database;
      await db.update(table, values, where: 'id = ?', whereArgs: [id]);
    }

    Matcher conflictOn(String table, String id) => throwsA(isA<BackupConflictException>().having(
        (e) => e.conflicts.map((c) => '${c.table}:${c.id}').toList(), 'conflicts', contains('$table:$id')));

    test('same ID + same content is treated as already existing (no conflict, nothing duplicated)', () async {
      final b = await backupOfSeed();
      final before = await snapshot();
      final r = await svc.restore(b, RestoreMode.merge);
      expect([r.transactions, r.categories, r.persons, r.debtTransactions], [0, 0, 0, 0]);
      expect(await snapshot(), before);
    });

    test('same ID + different content is an ID conflict: refused, with a clear message, nothing changed', () async {
      final b = await backupOfSeed();
      // existing d1 now looks like "Karim, 10000" while the backup says "Rahim, 5000"
      await h.insertPerson(person('p2', 'Karim'));
      await update('debt_transactions', {'personId': 'p2', 'amount': 10000.0}, 'd1');
      final before = await snapshot();

      try {
        await svc.restore(b, RestoreMode.merge);
        fail('expected a BackupConflictException');
      } on BackupConflictException catch (e) {
        expect(e, isA<BackupException>()); // so the existing UI shows e.userMessage
        expect(e.userMessage, contains('Merge করা যায়নি'));
        expect(e.userMessage, isNot(contains('d1'))); // no IDs in the user-facing text
        expect(e.conflicts.map((c) => '${c.table}:${c.id}'), contains('debt_transactions:d1'));
      }
      expect(await snapshot(), before); // atomic: the refused merge wrote nothing
    });

    test('a ledger entry whose sourceId points at a CONFLICTED debt transaction is never linked to it', () async {
      final b = await backupOfSeed(); // contains m1 (sourceId = d1)
      await h.deleteTransaction('m1'); // the database lacks m1, so a merge would insert it
      await update('debt_transactions', {'amount': 9999.0}, 'd1'); // d1 exists with different content
      final before = await snapshot();

      await expectLater(svc.restore(b, RestoreMode.merge), conflictOn('debt_transactions', 'd1'));

      final all = await h.getAllTransactions();
      expect(all.where((t) => t.id == 'm1'), isEmpty); // not inserted
      expect(all.where((t) => t.sourceId == 'd1'), isEmpty); // nothing attached to the wrong d1
      expect(await snapshot(), before);
    });

    test('a normal merge still adds new records and links them to the right debt transaction', () async {
      await seed();
      await h.insertPerson(person('p2', 'Karim'));
      await h.insertDebtTransaction(dtx('d3', 'p2', DebtType.gave, 70),
          mirror: tx('m3', amount: 70, sourceId: 'd3'));
      final b = svc.parse(await svc.buildBackupJson());
      await h.deletePersonCascade('p2'); // the database no longer has p2 / d3 / m3

      final r = await svc.restore(b, RestoreMode.merge);

      expect([r.persons, r.debtTransactions, r.transactions], [1, 1, 1]);
      final all = await h.getAllTransactions();
      expect(all.firstWhere((t) => t.id == 'm3').sourceId, 'd3');
      expect((await h.getAllDebtTransactions()).map((d) => d.id), containsAll(['d1', 'd2', 'd3']));
      expect((await h.getAllPersons()).map((p) => p.id), containsAll(['p1', 'p2']));
      expect((await h.getAllDebtTransactions()).firstWhere((d) => d.id == 'd1').amount, 5000);
    });

    test('Replace restore is unaffected by ID conflicts', () async {
      final b = await backupOfSeed();
      await update('debt_transactions', {'amount': 9999.0}, 'd1');
      await svc.restore(b, RestoreMode.replace);
      expect((await h.getAllDebtTransactions()).firstWhere((d) => d.id == 'd1').amount, 5000);
    });

    test('every record type is checked: person, category, ledger entry and its sourceId', () async {
      final b = await backupOfSeed();
      await update('debt_persons', {'name': 'Someone else'}, 'p1');
      await update('categories', {'name': 'Renamed'}, 'c1');
      await update('transactions', {'amount': 1.0}, 't1');
      await update('transactions', {'sourceId': null}, 'm1');
      final before = await snapshot();

      try {
        await svc.restore(b, RestoreMode.merge);
        fail('expected a BackupConflictException');
      } on BackupConflictException catch (e) {
        final ids = e.conflicts.map((c) => '${c.table}:${c.id}').toSet();
        expect(ids, containsAll(['debt_persons:p1', 'categories:c1', 'transactions:t1', 'transactions:m1']));
      }
      expect(await snapshot(), before);
    });

    test('cosmetic / device-local differences (icons, a person photo path) are NOT conflicts', () async {
      final b = await backupOfSeed();
      await update('transactions', {'icon': '🎯'}, 't1');
      await update('categories', {'icon': '🎯'}, 'c1');
      await update('debt_persons', {'imagePath': '/some/other/device/photo.jpg'}, 'p1');
      final r = await svc.restore(b, RestoreMode.merge);
      expect([r.transactions, r.categories, r.persons, r.debtTransactions], [0, 0, 0, 0]);
    });
  });
}
