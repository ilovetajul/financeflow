# Google Drive backup – external configuration required

This part **cannot be verified from the source code or from CI**. It lives in your
Google Cloud project. Nothing in this repository contains (or should contain) credentials.

## What the code expects (verified by reading `backup_screen.dart`)

```dart
GoogleSignIn(scopes: ['email', 'https://www.googleapis.com/auth/drive.appdata'])
```

* No `clientId` and no `serverClientId` are passed. On Android, `google_sign_in`
  therefore uses native Google Play Services sign-in, and Google decides whether
  the app is allowed by matching **package name + signing-certificate SHA-1**
  against an **Android-type OAuth client** in your Google Cloud project.
* It reads `account.authentication.accessToken` and calls the Drive REST API
  (`drive/v3/files`, `spaces=appDataFolder`) directly with `package:http`.
  The backup is a single file, `financeflow_backup.json`, in the app's hidden
  `appDataFolder` (invisible in the user's normal Drive).
* `google-services.json` is **not used**: no `com.google.gms.google-services`
  plugin is applied, no Firebase package is a dependency, and the file's
  `oauth_client` list is empty (it holds no sign-in client and no SHA-1).
  Do not edit it to try to fix sign-in.

## Package ID

`com.example.financeflow` – identical in `android/app/build.gradle` (namespace and
applicationId), `MainActivity.kt` and `google-services.json`. The previous CI built
with a generated ID (`com.example.temp_app`); if your OAuth client was ever created
for that ID it must be replaced/added for `com.example.financeflow`.

## What you must configure in Google Cloud (I cannot do or check this)

1. **Google Drive API** enabled in the project.
2. **OAuth consent screen** configured, including the scope
   `https://www.googleapis.com/auth/drive.appdata`. While the consent screen is in
   *Testing* status, only accounts listed as test users can sign in.
3. An **OAuth client ID of type "Android"** with:
   * Package name: `com.example.financeflow`
   * SHA-1 certificate fingerprint of the key that signs the APK being installed.
4. If the app is ever published through Google Play with *Play App Signing*, also add
   the SHA-1 of Play's app-signing key (shown in Play Console).

Get your local debug SHA-1:

```
keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey \
        -storepass android -keypass android
```

## Signing key and CI-built APKs

By default `android/app/build.gradle` signs the release build with the **debug** key of the GitHub runner. Sign-in and
Drive backup were verified manually on one CI-built APK whose signing SHA-1 had been registered on the Android OAuth
client (before the Phase-1 patch; that patch did not modify the sign-in code and has not been re-tested). Whether the
runner's debug key is identical from one run to the next has **not been verified**; if it changes, each new SHA-1 has to
be registered again. Once a stable release keystore is configured (GitHub Secrets, see
[`RELEASE_SIGNING.md`](RELEASE_SIGNING.md)), CI release APKs are signed with it. **Its SHA-1 must then be registered
on an Android OAuth client for `com.example.financeflow`** in Google Cloud (steps in `RELEASE_SIGNING.md`).

## Symptoms when it is misconfigured

Sign-in fails and the app shows "Google লগইন করা যায়নি।" followed by a short diagnostic line in
brackets, for example `(PlatformException code=sign_in_failed message=...ApiException: 10:)`. The same
line is written to the log (`adb logcat`, tag `I/flutter`, prefix `[FinanceFlow] signIn:`), also in release
builds. It contains only the exception type, the plugin error code and a sanitised message (e-mail
addresses and token-like strings are removed). Typical meanings (from general knowledge of `google_sign_in`
on Android, not reproduced against your project): `ApiException: 10` = developer error (package/SHA-1 not
registered for the installed APK), `12500` = consent screen / Play Services configuration, `7` = network.

## Why no `serverClientId` / Web client ID is set

The app only needs an access token for the Drive REST API, which Google issues based on the **Android**
OAuth client (package + SHA-1). A Web client ID is only needed to obtain an ID token or a server auth code
for a backend, which this app does not use. Setting `serverClientId` also requires the Web client to be in
the same Google Cloud project as the Android client, which adds a failure mode without adding a feature.

## Local backups do not depend on any of this

Local backup/restore (file export, share sheet, file picker) works without Google.
