# Release signing (stable key) and Google Sign-In

## Status

| Situation | Release APK is signed with |
|---|---|
| No signing values provided (default, local development, forks) | the **debug** key (as before; works, but the key is not guaranteed to be stable) |
| All four signing values provided | your **release keystore** |
| Only some values provided | the build **fails** on purpose (so a half-configured pipeline can never ship a debug-signed release) |

No keystore, password or key is stored in this repository. `*.jks`, `*.keystore`, `*.p12` and
`android/key.properties` are git-ignored. The package ID stays `com.example.financeflow`.

## Why a stable release key matters

* **Google Drive backup:** Google Sign-In accepts the app only if the SHA-1 of the key that signed the installed
  APK is registered on an Android OAuth client for `com.example.financeflow`. A debug key created on a GitHub
  runner may differ from run to run (not verified; sign-in did work on one CI-built APK whose SHA-1 was registered),
  in which case every new CI APK would need its SHA-1 registered again. A stable release key avoids that.
* **Updates:** Android only installs an update if it is signed with the same key as the installed app.

## One-time setup

1. **Create a keystore on your own computer** (needs a JDK). Keep it out of the repository:

   ```bash
   keytool -genkeypair -v -keystore financeflow-release.jks -alias financeflow \
           -keyalg RSA -keysize 2048 -validity 10000
   ```

   Back up the `.jks` file **and** both passwords somewhere safe and private (for example a password manager).
   If you lose them you can never publish an update signed with the same key, and the SHA-1 registered in
   Google Cloud becomes useless.

2. **Read its SHA-1 / SHA-256:**

   ```bash
   keytool -list -v -keystore financeflow-release.jks -alias financeflow
   ```

3. **Register the SHA-1 in Google Cloud** (see the next section).

4. **Add four GitHub Secrets** (repository -> Settings -> Secrets and variables -> Actions):

   | Secret | Value |
   |---|---|
   | `ANDROID_KEYSTORE_BASE64` | the keystore file, base64-encoded on one line: Linux `base64 -w0 financeflow-release.jks`; macOS `base64 -i financeflow-release.jks \| tr -d '\n'`; PowerShell `[Convert]::ToBase64String([IO.File]::ReadAllBytes("financeflow-release.jks"))` |
   | `ANDROID_KEYSTORE_PASSWORD` | the keystore (store) password |
   | `ANDROID_KEY_ALIAS` | the key alias (`financeflow` in the example) |
   | `ANDROID_KEY_PASSWORD` | the key password |

   Set **all four or none**. Values must be single-line and must not start with a space.

## What CI does

The step "Prepare release signing" decodes the keystore into the runner's temporary folder and writes
`android/key.properties` (mode 600). Gradle reads it for `flutter build apk --release`. Secret values are never
printed, and the step "Remove signing material" deletes both files at the end. Pull requests from forks have no
access to secrets, so they fall back to the debug key.

To confirm which key signed a build, open the run's Summary or the step "Signing certificate diagnostic": it prints
the SHA-1 and SHA-256 of both release APKs. They must equal the values from step 2.

## Google Cloud: SHA-1 action required after switching to the release keystore

Google Sign-In (Drive backup) will fail with the release APK until the release key is registered:

1. Google Cloud Console -> the **FinanceFlow** project (the one where the Drive API is enabled)
   -> APIs & Services -> Credentials.
2. Create a **new OAuth client ID of type "Android"** with package name `com.example.financeflow` and the
   **SHA-1 of the release keystore** (step 2). Keep the existing client that has the old SHA-1 if you still use
   debug-signed builds.
3. If you later publish through Google Play with *Play App Signing*, also register the SHA-1 shown by Play Console
   (Play re-signs the app with its own key).

No code change is needed: the app does not set `serverClientId`.

## Switching an already-installed app (important)

An APK signed with the release key **cannot be installed over** an installed app signed with the debug key
(Android reports a signature mismatch). You would have to uninstall first, which **deletes the app's data**.
Before doing that, create a local backup in the app (Backup tab -> Local backup) and keep the file, then restore it
after installing the release-signed APK.

## Local release build with the release key

Create `android/key.properties` from `android/key.properties.example` (it is git-ignored), then run
`flutter build apk --release`. Alternatively export `ANDROID_KEYSTORE_PATH`, `ANDROID_KEYSTORE_PASSWORD`,
`ANDROID_KEY_ALIAS` and `ANDROID_KEY_PASSWORD`. Gradle prints which key it will use
("FinanceFlow release signing: RELEASE keystore" or "... DEBUG key ...") and never prints values.
