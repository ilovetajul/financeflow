// lib/data/backup/backup_service.dart
//
// Full, versioned backup & safe restore.
//
// File format (backupVersion 2):
// {
//   "backupVersion": 2, "appName": "FinanceFlow", "appVersion": "1.0.0",
//   "schemaVersion": 2,
//   "createdAt": "2026-09-30T14:15:00.000Z",     // UTC instant
//   "timezoneOffsetMinutes": 360,                // device offset when created
//   "database": { "transactions": [...], "categories": [...] },
//   "debt":     { "persons": [...], "transactions": [...] },
//   "settings": { "userName": "...", "userPhone": "..." }
// }
// Dates inside records are the app's local wall-clock ISO strings, copied
// verbatim (never converted), so restore cannot shift a date.
//
// Legacy files written by the old app ({"version":1|2,"transactions":[..],
// "categories":[..]}) are detected and upgraded in memory. They contain no
// debt data, so restoring one never touches the current debt records.
//
// Not included on purpose: the PIN (secret), profile/person photo files
// (device-local file paths), Google account/session data.

import 'dart:convert';
import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import '../../core/app_info.dart';
import '../../core/app_log.dart';
import '../local/database_helper.dart';

enum RestoreMode { replace, merge }

/// Error whose [userMessage] is safe (Bengali) to show to the user.
class BackupException implements Exception {
  final String userMessage;
  final Object? cause;
  BackupException(this.userMessage, [this.cause]);
  @override
  String toString() => 'BackupException'; // never leaks details
}

/// One incoming record whose ID already exists with different content.
class BackupConflict {
  final String table; // transactions | debt_transactions | debt_persons | categories
  final String id;
  const BackupConflict(this.table, this.id);
}

/// Thrown by a Merge restore when at least one incoming record has the same ID as an
/// existing record but materially different content. The merge is refused as a
/// whole: the database transaction is rolled back and nothing has been changed.
/// (Extends [BackupException], so existing UI code shows [userMessage] as is.)
class BackupConflictException extends BackupException {
  final List<BackupConflict> conflicts;
  BackupConflictException(this.conflicts) : super(_describe(conflicts));

  static const _names = {
    'transactions': 'লেনদেন',
    'debt_transactions': 'দেনা-পাওনা লেনদেন',
    'debt_persons': 'দেনা-পাওনার ব্যক্তি',
    'categories': 'category',
  };

  static String _describe(List<BackupConflict> c) {
    final byTable = <String, int>{};
    for (final x in c) {
      byTable[x.table] = (byTable[x.table] ?? 0) + 1;
    }
    final parts = byTable.entries.map((e) => '${_names[e.key] ?? e.key}: ${e.value}').join(', ');
    // No IDs or amounts in the message: it is shown to the user.
    return 'Merge করা যায়নি: ${c.length}টি রেকর্ডের ID আগে থেকেই আছে, কিন্তু তথ্য আলাদা ($parts)। '
        'কোনো ডেটা পরিবর্তন করা হয়নি। নিশ্চিত না হলে "Replace All" ব্যবহার করুন '
        '(তার আগে স্বয়ংক্রিয়ভাবে নিরাপত্তা backup নেওয়া হবে)।';
  }

  @override
  String toString() => 'BackupConflictException';
}

class Msg {
  Msg._();
  static const invalid =
      'Backup ফাইলটি সঠিক নয় বা অসম্পূর্ণ। আপনার বর্তমান ডেটা পরিবর্তন করা হয়নি।';
  static const newer =
      'এই backup FinanceFlow-এর নতুন ভার্সনে তৈরি, তাই নিরাপদে restore করা যাবে না। অ্যাপ আপডেট করুন।';
  static const emergencyFailed =
      'Restore-এর আগে নিরাপত্তা backup তৈরি করা যায়নি, তাই restore বন্ধ করা হয়েছে। আপনার ডেটা অপরিবর্তিত আছে।';
  static const restoreFailed =
      'Restore সম্পন্ন হয়নি। আপনার আগের ডেটা অপরিবর্তিত আছে।';
}

class ParsedBackup {
  final int version;
  final bool isLegacy;
  final String? appVersion;
  final String? createdAt;
  final List<Map<String, Object?>> transactions;
  final List<Map<String, Object?>> categories;
  final List<Map<String, Object?>> persons;
  final List<Map<String, Object?>> debtTransactions;
  final Map<String, String> settings;
  final bool includesCategories;
  final bool includesDebt;
  ParsedBackup({
    required this.version,
    required this.isLegacy,
    required this.appVersion,
    required this.createdAt,
    required this.transactions,
    required this.categories,
    required this.persons,
    required this.debtTransactions,
    required this.settings,
    required this.includesCategories,
    required this.includesDebt,
  });
}

class RestoreReport {
  final RestoreMode mode;
  final int transactions;
  final int categories;
  final int persons;
  final int debtTransactions;
  final String emergencyBackupPath;
  const RestoreReport({
    required this.mode,
    required this.transactions,
    required this.categories,
    required this.persons,
    required this.debtTransactions,
    required this.emergencyBackupPath,
  });
}

class BackupService {
  static const int currentVersion = 2;

  final DatabaseHelper _helper;
  final Future<Directory> Function() _emergencyDir;

  BackupService({DatabaseHelper? helper, Future<Directory> Function()? emergencyDir})
      : _helper = helper ?? DatabaseHelper.instance,
        _emergencyDir = emergencyDir ?? _defaultEmergencyDir;

  static Future<Directory> _defaultEmergencyDir() async {
    final base = await getApplicationDocumentsDirectory();
    final d = Directory(p.join(base.path, 'emergency_backups'));
    if (!await d.exists()) await d.create(recursive: true);
    return d;
  }

  /// FinanceFlow_Backup_2026-09-30_2015.json (local time, Android-safe).
  static String fileName([DateTime? now, String prefix = 'FinanceFlow_Backup']) {
    final n = now ?? DateTime.now();
    String t(int v) => v.toString().padLeft(2, '0');
    return '${prefix}_${n.year}-${t(n.month)}-${t(n.day)}_${t(n.hour)}${t(n.minute)}.json';
  }

  // ═════════════════════════════ BUILD ═════════════════════════════════
  Future<String> buildBackupJson({DateTime? now}) async {
    final db = await _helper.database;
    final n = now ?? DateTime.now();
    // Read inside one transaction so all tables are from the same instant.
    late List<Map<String, Object?>> tx, cats, persons, dtx;
    await db.transaction((txn) async {
      tx = await txn.query('transactions', orderBy: 'date ASC, id ASC');
      cats = await txn.query('categories', orderBy: 'position ASC, rowid ASC');
      persons = await txn.query('debt_persons', orderBy: 'rowid ASC');
      dtx = await txn.query('debt_transactions', orderBy: 'rowid ASC');
    });
    final prefs = await SharedPreferences.getInstance();
    final settings = <String, String>{
      if ((prefs.getString('user_name') ?? '').isNotEmpty)
        'userName': prefs.getString('user_name')!,
      if ((prefs.getString('user_phone') ?? '').isNotEmpty)
        'userPhone': prefs.getString('user_phone')!,
    };
    return jsonEncode({
      'backupVersion': currentVersion,
      'appName': AppInfo.name,
      'appVersion': AppInfo.version,
      'schemaVersion': DatabaseHelper.schemaVersion,
      'createdAt': n.toUtc().toIso8601String(),
      'timezoneOffsetMinutes': n.timeZoneOffset.inMinutes,
      'database': {
        'transactions': tx.map(_cleanTx).toList(),
        'categories': cats.map(_cleanCat).toList(),
      },
      'debt': {
        'persons': persons.map(_cleanPerson).toList(),
        'transactions': dtx.map(_cleanDebtTx).toList(),
      },
      'settings': settings,
    });
  }

  Future<bool> hasAnyData() async {
    final db = await _helper.database;
    for (final t in ['transactions', 'debt_persons', 'debt_transactions']) {
      if ((Sqflite.firstIntValue(await db.rawQuery('SELECT COUNT(*) FROM $t')) ?? 0) > 0) {
        return true;
      }
    }
    return false;
  }

  // ═════════════════════════════ PARSE / VALIDATE ══════════════════════
  /// Validates and (if needed) upgrades a backup. Throws [BackupException]
  /// with a safe message; never touches the database.
  ParsedBackup parse(String text) {
    try {
      final decoded = jsonDecode(text);
      if (decoded is! Map) throw const FormatException('root');
      final root = Map<String, dynamic>.from(decoded);

      if (root.containsKey('backupVersion')) {
        final v = root['backupVersion'];
        if (v is! int || v < 1) throw const FormatException('backupVersion');
        if (v > currentVersion) throw BackupException(Msg.newer);
        if (v != 2) throw const FormatException('unknown backupVersion');
        return _parseV2(root);
      }
      if (root.containsKey('transactions') && !root.containsKey('database')) {
        return _parseLegacy(root);
      }
      throw const FormatException('unrecognised file');
    } on BackupException {
      rethrow;
    } catch (e, st) {
      appLog('BackupService.parse', e, st);
      throw BackupException(Msg.invalid, e);
    }
  }

  ParsedBackup _parseV2(Map<String, dynamic> root) {
    final db = _map(root['database']);
    final debt = _map(root['debt']);
    final tx = _rows(db['transactions'], _cleanTxStrict);
    final cats = _rows(db['categories'], _cleanCatStrict);
    final persons = _rows(debt['persons'], _cleanPersonStrict);
    final dtx = _rows(debt['transactions'], _cleanDebtTxStrict);
    _checkUnique(tx, 'id');
    _checkUnique(cats, 'id');
    _checkUnique(persons, 'id');
    _checkUnique(dtx, 'id');
    final personIds = persons.map((e) => e['id']).toSet();
    for (final t in dtx) {
      if (!personIds.contains(t['personId'])) {
        throw const FormatException('debt tx references missing person');
      }
    }
    final debtIds = dtx.map((e) => e['id']).toSet();
    for (final t in tx) {
      final s = t['sourceId'];
      if (s != null && !debtIds.contains(s)) {
        // A ledger entry pointing at a debt transaction that is not in the
        // file would be an unexplained dangling link. Treat as corrupt.
        throw const FormatException('dangling sourceId');
      }
    }
    final rawSettings = root['settings'];
    final settings = <String, String>{};
    if (rawSettings is Map) {
      for (final k in ['userName', 'userPhone']) {
        final v = rawSettings[k];
        if (v is String && v.isNotEmpty) settings[k] = v;
      }
    }
    return ParsedBackup(
      version: 2,
      isLegacy: false,
      appVersion: root['appVersion'] as String?,
      createdAt: root['createdAt'] as String?,
      transactions: tx,
      categories: cats,
      persons: persons,
      debtTransactions: dtx,
      settings: settings,
      includesCategories: true,
      includesDebt: true,
    );
  }

  /// Upgrade path for files written by the original app (no debt data).
  ParsedBackup _parseLegacy(Map<String, dynamic> root) {
    final v = root['version'];
    if (v != null && v is! int) throw const FormatException('version');
    final version = (v as int?) ?? 1;
    if (version > 2) throw BackupException(Msg.newer);
    final tx = _rows(root['transactions'], _cleanTxStrict);
    _checkUnique(tx, 'id');
    final hasCats = version >= 2 && root.containsKey('categories');
    final cats = hasCats ? _rows(root['categories'], _cleanCatStrict) : <Map<String, Object?>>[];
    _checkUnique(cats, 'id');
    return ParsedBackup(
      version: version,
      isLegacy: true,
      appVersion: null,
      createdAt: root['exportedAt'] as String?,
      transactions: tx,
      categories: cats,
      persons: const [],
      debtTransactions: const [],
      settings: const {},
      includesCategories: hasCats,
      includesDebt: false,
    );
  }

  // ═════════════════════════════ RESTORE ═══════════════════════════════
  /// Writes a full backup of the CURRENT data to app storage and verifies it
  /// can be read back. Returns the file path.
  Future<String> createEmergencyBackup() async {
    try {
      final json = await buildBackupJson();
      parse(json); // must be a valid backup, or it is useless as a safety net
      final dir = await _emergencyDir();
      final now = DateTime.now();
      final secs = now.second.toString().padLeft(2, '0');
      // seconds in the name so two restores in the same minute never overwrite
      final base = fileName(now, 'FinanceFlow_PreRestore').replaceAll('.json', '');
      final file = File(p.join(dir.path, '${base}_$secs.json'));
      await file.writeAsString(json, flush: true);
      if (await file.readAsString() != json) {
        throw const FileSystemException('verify');
      }
      await _pruneEmergency(dir);
      return file.path;
    } catch (e, st) {
      appLog('BackupService.createEmergencyBackup', e, st);
      throw BackupException(Msg.emergencyFailed, e);
    }
  }

  Future<void> _pruneEmergency(Directory dir) async {
    try {
      final files = dir
          .listSync()
          .whereType<File>()
          .where((f) => p.basename(f.path).startsWith('FinanceFlow_PreRestore_'))
          .toList()
        ..sort((a, b) => a.path.compareTo(b.path));
      while (files.length > 5) {
        await files.removeAt(0).delete();
      }
    } catch (_) {/* housekeeping only */}
  }

  /// Validated restore: emergency backup first, then one atomic SQLite
  /// transaction. If anything fails the database is left exactly as it was.
  Future<RestoreReport> restore(ParsedBackup b, RestoreMode mode) async {
    final emergencyPath = await createEmergencyBackup();
    final db = await _helper.database;
    try {
      late RestoreReport report;
      await db.transaction((txn) async {
        report = mode == RestoreMode.replace
            ? await _replace(txn, b, emergencyPath)
            : await _merge(txn, b, emergencyPath);
      });
      await _applySettings(b, mode);
      return report;
    } on BackupConflictException {
      rethrow; // already rolled back; keep the specific message
    } catch (e, st) {
      appLog('BackupService.restore', e, st);
      // SQLite already rolled the transaction back; data is unchanged and the
      // emergency backup still exists as an extra safety net.
      throw BackupException(Msg.restoreFailed, e);
    }
  }

  Future<RestoreReport> _replace(DatabaseExecutor txn, ParsedBackup b, String emergency) async {
    // children first
    if (b.includesDebt) {
      await txn.delete('debt_transactions');
      await txn.delete('debt_persons');
    }
    await txn.delete('transactions');
    if (b.includesCategories) await txn.delete('categories');

    final batch = txn.batch();
    for (var i = 0; i < b.categories.length; i++) {
      batch.insert('categories', {...b.categories[i], 'position': i},
          conflictAlgorithm: ConflictAlgorithm.abort);
    }
    for (final r in b.persons) {
      batch.insert('debt_persons', r, conflictAlgorithm: ConflictAlgorithm.abort);
    }
    for (final r in b.debtTransactions) {
      batch.insert('debt_transactions', r, conflictAlgorithm: ConflictAlgorithm.abort);
    }
    for (final r in b.transactions) {
      batch.insert('transactions', r, conflictAlgorithm: ConflictAlgorithm.abort);
    }
    await batch.commit(noResult: true);

    Future<void> expect(String table, int n) async {
      final have = Sqflite.firstIntValue(await txn.rawQuery('SELECT COUNT(*) FROM $table')) ?? -1;
      if (have != n) throw StateError('count mismatch in $table');
    }

    await expect('transactions', b.transactions.length);
    if (b.includesCategories) await expect('categories', b.categories.length);
    if (b.includesDebt) {
      await expect('debt_persons', b.persons.length);
      await expect('debt_transactions', b.debtTransactions.length);
    }
    return RestoreReport(
      mode: RestoreMode.replace,
      transactions: b.transactions.length,
      categories: b.categories.length,
      persons: b.persons.length,
      debtTransactions: b.debtTransactions.length,
      emergencyBackupPath: emergency,
    );
  }

  /// Merge = add what is missing, never overwrite or delete existing rows.
  /// Records are matched by their stable id (UUIDs). Categories are also
  /// matched by type+name so the same category is not added twice under a
  /// different id. Records with a different id but identical content are NOT
  /// treated as duplicates (that cannot be decided reliably).
  Future<RestoreReport> _merge(DatabaseExecutor txn, ParsedBackup b, String emergency) async {
    // An existing record with the same ID but different content is an ID conflict.
    // Refuse the whole merge BEFORE writing anything: ignoring such a record would
    // leave the backup's other records (e.g. a ledger entry whose sourceId points at
    // that ID) silently attached to the wrong, different existing record.
    final conflicts = await _findMergeConflicts(txn, b);
    if (conflicts.isNotEmpty) throw BackupConflictException(conflicts);

    Future<int> count(String t) async =>
        Sqflite.firstIntValue(await txn.rawQuery('SELECT COUNT(*) FROM $t')) ?? 0;

    final before = {
      for (final t in ['transactions', 'categories', 'debt_persons', 'debt_transactions'])
        t: await count(t)
    };

    final existingCats = (await txn.query('categories', columns: ['type', 'name']))
        .map((r) => '${r['type']}|${r['name']}')
        .toSet();
    var pos = await count('categories');
    for (final r in b.categories) {
      if (existingCats.contains('${r['type']}|${r['name']}')) continue;
      await txn.insert('categories', {...r, 'position': pos++},
          conflictAlgorithm: ConflictAlgorithm.ignore);
    }
    for (final r in b.persons) {
      await txn.insert('debt_persons', r, conflictAlgorithm: ConflictAlgorithm.ignore);
    }
    for (final r in b.debtTransactions) {
      await txn.insert('debt_transactions', r, conflictAlgorithm: ConflictAlgorithm.ignore);
    }
    for (final r in b.transactions) {
      // A linked ledger entry whose debt transaction was ignored/missing would
      // violate nothing in SQL (no FK) but would be dangling – drop the link.
      final row = {...r};
      final s = row['sourceId'];
      if (s != null) {
        final n = Sqflite.firstIntValue(await txn
            .rawQuery('SELECT COUNT(*) FROM debt_transactions WHERE id = ?', [s]));
        if ((n ?? 0) == 0) row['sourceId'] = null;
      }
      await txn.insert('transactions', row, conflictAlgorithm: ConflictAlgorithm.ignore);
    }
    return RestoreReport(
      mode: RestoreMode.merge,
      transactions: await count('transactions') - before['transactions']!,
      categories: await count('categories') - before['categories']!,
      persons: await count('debt_persons') - before['debt_persons']!,
      debtTransactions: await count('debt_transactions') - before['debt_transactions']!,
      emergencyBackupPath: emergency,
    );
  }

  /// Compares every incoming record with the existing record of the same ID.
  /// Only meaningful fields are compared: cosmetic fields (icon, position) and
  /// device-local ones (a person's photo path) are ignored.
  Future<List<BackupConflict>> _findMergeConflicts(DatabaseExecutor txn, ParsedBackup b) async {
    final conflicts = <BackupConflict>[];

    Future<void> check(
      String table,
      List<Map<String, Object?>> incoming,
      bool Function(Map<String, Object?> existing, Map<String, Object?> incoming) same,
    ) async {
      if (incoming.isEmpty) return;
      final existing = {for (final r in await txn.query(table)) r['id'] as String: r};
      for (final row in incoming) {
        final current = existing[row['id']];
        if (current != null && !same(current, row)) {
          conflicts.add(BackupConflict(table, row['id'] as String));
        }
      }
    }

    await check('categories', b.categories,
        (e, i) => _eq(e['type'], i['type']) && _eq(e['name'], i['name']));
    await check('debt_persons', b.persons,
        (e, i) => _eq(e['name'], i['name']) && _eq(e['phone'], i['phone']));
    await check(
        'debt_transactions',
        b.debtTransactions,
        (e, i) =>
            _eq(e['personId'], i['personId']) &&
            _eq(e['type'], i['type']) &&
            _sameAmount(e['amount'], i['amount']) &&
            _sameDate(e['date'], i['date']) &&
            _eq(e['note'], i['note']));
    await check(
        'transactions',
        b.transactions,
        (e, i) =>
            _eq(e['type'], i['type']) &&
            _eq(e['category'], i['category']) &&
            _sameAmount(e['amount'], i['amount']) &&
            _sameDate(e['date'], i['date']) &&
            _eq(e['note'], i['note']) &&
            _eq(e['sourceId'], i['sourceId']));
    return conflicts;
  }

  static String _txt(Object? v) => v == null ? '' : v.toString();
  static bool _eq(Object? a, Object? b) => _txt(a) == _txt(b); // null and '' are the same
  static bool _sameAmount(Object? a, Object? b) {
    final x = (a as num?)?.toDouble(), y = (b as num?)?.toDouble();
    return x != null && y != null && (x - y).abs() < 0.005;
  }

  static bool _sameDate(Object? a, Object? b) {
    if (_txt(a) == _txt(b)) return true;
    final x = DateTime.tryParse(_txt(a)), y = DateTime.tryParse(_txt(b));
    return x != null && y != null && x.isAtSameMomentAs(y);
  }

  Future<void> _applySettings(ParsedBackup b, RestoreMode mode) async {
    if (b.settings.isEmpty) return;
    try {
      final prefs = await SharedPreferences.getInstance();
      final map = {'userName': 'user_name', 'userPhone': 'user_phone'};
      for (final e in b.settings.entries) {
        final key = map[e.key];
        if (key == null) continue;
        if (mode == RestoreMode.merge && (prefs.getString(key) ?? '').isNotEmpty) continue;
        await prefs.setString(key, e.value);
      }
    } catch (e, st) {
      appLog('BackupService._applySettings', e, st); // non-critical
    }
  }

  // ═════════════════════════ row cleaning / validation ═════════════════
  static Map<String, dynamic> _map(Object? v) {
    if (v is! Map) throw const FormatException('expected object');
    return Map<String, dynamic>.from(v);
  }

  static List<Map<String, Object?>> _rows(
      Object? v, Map<String, Object?> Function(Map<String, dynamic>) clean) {
    if (v is! List) throw const FormatException('expected list');
    return v.map((e) => clean(_map(e))).toList();
  }

  static void _checkUnique(List<Map<String, Object?>> rows, String key) {
    final seen = <Object?>{};
    for (final r in rows) {
      if (!seen.add(r[key])) throw const FormatException('duplicate id');
    }
  }

  static String _s(Map<String, dynamic> m, String k, {bool required = true, String def = ''}) {
    final v = m[k];
    if (v == null) {
      if (required) throw FormatException('missing $k');
      return def;
    }
    if (v is! String) throw FormatException('bad $k');
    if (required && v.isEmpty) throw FormatException('empty $k');
    return v;
  }

  static double _amount(Map<String, dynamic> m) {
    final v = m['amount'];
    if (v is! num) throw const FormatException('bad amount');
    final d = v.toDouble();
    if (d.isNaN || d.isInfinite || d < 0) throw const FormatException('bad amount');
    return d;
  }

  /// Validates a date string and normalises zone-qualified values to local
  /// wall-clock; plain local strings are kept byte-for-byte.
  static String _date(Map<String, dynamic> m) {
    final raw = _s(m, 'date');
    final dt = DateTime.tryParse(raw);
    if (dt == null) throw const FormatException('bad date');
    return dt.isUtc ? dt.toLocal().toIso8601String() : raw;
  }

  static Map<String, Object?> _cleanTxStrict(Map<String, dynamic> m) {
    final type = _s(m, 'type');
    if (type != 'income' && type != 'expense') throw const FormatException('bad type');
    final src = m['sourceId'];
    if (src != null && (src is! String || src.isEmpty)) {
      throw const FormatException('bad sourceId');
    }
    return {
      'id': _s(m, 'id'),
      'type': type,
      'category': _s(m, 'category'),
      'amount': _amount(m),
      'note': _s(m, 'note', required: false),
      'date': _date(m),
      'icon': _s(m, 'icon', required: false),
      'sourceId': src,
    };
  }

  static Map<String, Object?> _cleanCatStrict(Map<String, dynamic> m) {
    final type = _s(m, 'type');
    if (type != 'income' && type != 'expense') throw const FormatException('bad type');
    return {
      'id': _s(m, 'id'),
      'name': _s(m, 'name'),
      'icon': _s(m, 'icon', required: false),
      'type': type,
    };
  }

  static Map<String, Object?> _cleanPersonStrict(Map<String, dynamic> m) {
    final img = m['imagePath'];
    if (img != null && img is! String) throw const FormatException('bad imagePath');
    return {
      'id': _s(m, 'id'),
      'name': _s(m, 'name'),
      'phone': _s(m, 'phone', required: false),
      // Photos are device-local files; keep the path only if it exists here.
      'imagePath': (img is String && img.isNotEmpty && File(img).existsSync()) ? img : null,
    };
  }

  static Map<String, Object?> _cleanDebtTxStrict(Map<String, dynamic> m) {
    final type = _s(m, 'type');
    if (type != 'gave' && type != 'received') throw const FormatException('bad type');
    return {
      'id': _s(m, 'id'),
      'personId': _s(m, 'personId'),
      'amount': _amount(m),
      'type': type,
      'date': _date(m),
      'note': _s(m, 'note', required: false),
    };
  }

  // Export-side cleaners: copy DB rows verbatim (no conversion).
  static Map<String, Object?> _cleanTx(Map<String, Object?> r) => {
        'id': r['id'], 'type': r['type'], 'category': r['category'],
        'amount': r['amount'], 'note': r['note'] ?? '', 'date': r['date'],
        'icon': r['icon'], 'sourceId': r['sourceId'],
      };
  static Map<String, Object?> _cleanCat(Map<String, Object?> r) =>
      {'id': r['id'], 'name': r['name'], 'icon': r['icon'], 'type': r['type']};
  static Map<String, Object?> _cleanPerson(Map<String, Object?> r) => {
        'id': r['id'], 'name': r['name'], 'phone': r['phone'] ?? '',
        'imagePath': r['imagePath'],
      };
  static Map<String, Object?> _cleanDebtTx(Map<String, Object?> r) => {
        'id': r['id'], 'personId': r['personId'], 'amount': r['amount'],
        'type': r['type'], 'date': r['date'], 'note': r['note'] ?? '',
      };
}
