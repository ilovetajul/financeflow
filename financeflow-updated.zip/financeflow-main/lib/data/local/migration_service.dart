// lib/data/local/migration_service.dart
//
// One-time, verified copy of data that used to live in SharedPreferences
// (debt persons, debt transactions, categories) into SQLite (schema v2).
//
// Safety rules:
//  • The old SharedPreferences keys are NEVER deleted or modified here.
//  • Everything is inserted in ONE SQLite transaction together with the
//    "migration done" flag; any failure rolls the whole thing back.
//  • Counts/ids are verified before the flag is written.
//  • On failure nothing is marked complete, so the app can retry.
//  • Debt transactions whose person no longer exists (created by the old
//    "delete person" bug) cannot be linked to anyone. They are NOT silently
//    dropped: they stay untouched in the old SharedPreferences key and their
//    number is recorded in app_meta ('orphan_debt_tx_skipped').

import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import '../../core/app_log.dart';
import '../../domain/default_categories.dart';
import '../../domain/models/debt_model.dart';
import 'database_helper.dart';

class MigrationResult {
  final bool success;
  final String? userMessage; // Bengali, shown when !success
  final int persons;
  final int debtTransactions;
  final int categories;
  final int orphansSkipped;
  const MigrationResult.ok({
    this.persons = 0,
    this.debtTransactions = 0,
    this.categories = 0,
    this.orphansSkipped = 0,
  })  : success = true,
        userMessage = null;
  const MigrationResult.fail(String this.userMessage)
      : success = false,
        persons = 0,
        debtTransactions = 0,
        categories = 0,
        orphansSkipped = 0;
}

class MigrationService {
  static const metaDone = 'prefs_migration_v2';
  static const prefsPersons = 'debt_persons';
  static const prefsDebtTx = 'debt_transactions';
  static const prefsCategories = 'app_categories';

  final DatabaseHelper _helper;
  MigrationService([DatabaseHelper? helper]) : _helper = helper ?? DatabaseHelper.instance;

  Future<MigrationResult> runIfNeeded() async {
    try {
      if (await _helper.getMeta(metaDone) == 'done') {
        return const MigrationResult.ok();
      }
      return await _migrate();
    } catch (e, st) {
      appLog('MigrationService.runIfNeeded', e, st);
      return const MigrationResult.fail(
          'আপনার পুরনো ডেটা নতুন ফরম্যাটে আনা যায়নি। আপনার ডেটা মোছা হয়নি। আবার চেষ্টা করুন।');
    }
  }

  Future<MigrationResult> _migrate() async {
    final prefs = await SharedPreferences.getInstance();

    // ── 1. read + validate (no writes yet) ──────────────────────────────
    final persons = _decodeList(prefs.getString(prefsPersons))
        ?.map(DebtPerson.fromJson)
        .toList() ?? <DebtPerson>[];
    final allDebtTx = _decodeList(prefs.getString(prefsDebtTx))
        ?.map(DebtTransaction.fromJson)
        .toList() ?? <DebtTransaction>[];

    final personIds = <String>{};
    for (final p in persons) {
      if (p.id.isEmpty || !personIds.add(p.id)) {
        throw const FormatException('duplicate/empty person id');
      }
    }
    final txIds = <String>{};
    final debtTx = <DebtTransaction>[];
    var orphans = 0;
    for (final t in allDebtTx) {
      if (t.id.isEmpty || !txIds.add(t.id)) {
        throw const FormatException('duplicate/empty debt tx id');
      }
      if (t.amount.isNaN || t.amount.isInfinite || t.amount < 0) {
        throw const FormatException('bad debt amount');
      }
      if (!personIds.contains(t.personId)) {
        orphans++;
        continue;
      }
      debtTx.add(t);
    }

    List<Map<String, Object?>> categoryRows;
    final rawCats = prefs.getString(prefsCategories);
    if (rawCats == null) {
      categoryRows = kDefaultCategoryRows.map((e) => <String, Object?>{...e}).toList();
    } else {
      try {
        final list = _decodeList(rawCats) ?? const [];
        categoryRows = list.map((j) {
          final type = j['type'] as String;
          if (type != 'income' && type != 'expense') {
            throw const FormatException('bad category type');
          }
          return <String, Object?>{
            'id': j['id'] as String,
            'name': j['name'] as String,
            'icon': j['icon'] as String,
            'type': type,
          };
        }).toList();
        if (categoryRows.map((r) => r['id']).toSet().length != categoryRows.length) {
          throw const FormatException('duplicate category id');
        }
      } catch (e) {
        // The old app silently reset corrupted categories to defaults too.
        categoryRows = kDefaultCategoryRows.map((e) => <String, Object?>{...e}).toList();
      }
    }

    // ── 2. write + verify, all in one transaction ───────────────────────
    final db = await _helper.database;
    await db.transaction((txn) async {
      for (var i = 0; i < categoryRows.length; i++) {
        await txn.insert('categories', {...categoryRows[i], 'position': i},
            conflictAlgorithm: ConflictAlgorithm.ignore);
      }
      for (final p in persons) {
        await txn.insert('debt_persons', p.toJson(),
            conflictAlgorithm: ConflictAlgorithm.ignore);
      }
      for (final t in debtTx) {
        await txn.insert('debt_transactions', t.toJson(),
            conflictAlgorithm: ConflictAlgorithm.ignore);
      }

      // verify: every expected id must now exist
      Future<void> verify(String table, Iterable<String> expected) async {
        final have = (await txn.query(table, columns: ['id']))
            .map((r) => r['id'] as String)
            .toSet();
        if (!have.containsAll(expected)) {
          throw StateError('verification failed for $table');
        }
      }

      await verify('categories', categoryRows.map((r) => r['id'] as String));
      await verify('debt_persons', persons.map((p) => p.id));
      await verify('debt_transactions', debtTx.map((t) => t.id));

      await txn.insert('app_meta', {'key': 'orphan_debt_tx_skipped', 'value': '$orphans'},
          conflictAlgorithm: ConflictAlgorithm.replace);
      await txn.insert('app_meta', {'key': metaDone, 'value': 'done'},
          conflictAlgorithm: ConflictAlgorithm.replace);
    });

    return MigrationResult.ok(
      persons: persons.length,
      debtTransactions: debtTx.length,
      categories: categoryRows.length,
      orphansSkipped: orphans,
    );
  }

  /// Decodes a JSON list of objects. Null when [raw] is null/empty.
  /// Throws on malformed JSON so the migration fails instead of guessing.
  static List<Map<String, dynamic>>? _decodeList(String? raw) {
    if (raw == null || raw.isEmpty) return null;
    final decoded = jsonDecode(raw);
    if (decoded is! List) throw const FormatException('not a list');
    return decoded.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }
}
