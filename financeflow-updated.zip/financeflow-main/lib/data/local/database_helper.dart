// lib/data/local/database_helper.dart
//
// SQLite access for FinanceFlow.
//
// ── Schema history ──────────────────────────────────────────────────────────
// v1 (original): table `transactions` only. Debt data, categories, profile and
//                the PIN lived in SharedPreferences.
// v2 (this update), applied incrementally by [_migrateTo2]:
//   • transactions.sourceId  (nullable TEXT)  – links a ledger entry to the
//     debt transaction that created it. Existing rows get NULL.
//   • new table categories        (moved from SharedPreferences)
//   • new table debt_persons      (moved from SharedPreferences)
//   • new table debt_transactions (moved; FK personId → debt_persons ON DELETE CASCADE)
//   • new table app_meta          (key/value flags, e.g. migration status)
//   • indexes on transactions(date), debt_transactions(personId)
//   Nothing is dropped or rewritten in v2: existing `transactions` rows are
//   untouched. The data copy from SharedPreferences is done by
//   [MigrationService] (verified, retryable) and NOT inside onUpgrade, so the
//   old data is never deleted by a schema upgrade.
//
// ── Date/time strategy ──────────────────────────────────────────────────────
// All DateTime values are stored as LOCAL wall-clock ISO-8601 strings with no
// zone suffix (e.g. 2026-09-30T20:15:00.000), exactly what the original app
// wrote. Backups copy these strings verbatim, so a restore can never shift a
// date (2026-09-30 stays 2026-09-30). Only the backup `createdAt` metadata is
// UTC (with a 'Z'), because it is a point in time, not a user-entered date.
//
// ── Foreign keys ────────────────────────────────────────────────────────────
// PRAGMA foreign_keys = ON is set in onConfigure on every connection.

import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../../domain/models/transaction.dart' as model;
import '../../domain/models/debt_model.dart';

/// What the user is about to lose when deleting a debt person.
class PersonDeletionSummary {
  final int debtTransactionCount;
  final double balance; // >0: they owe me, <0: I owe them
  final int linkedLedgerCount; // main-ledger entries created from this person's debts
  const PersonDeletionSummary({
    required this.debtTransactionCount,
    required this.balance,
    required this.linkedLedgerCount,
  });
}

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._internal();
  static Database? _db;
  static const int schemaVersion = 2;
  static const String fileName = 'financeflow.db';

  DatabaseHelper._internal();

  Future<Database> get database async {
    _db ??= await _initDatabase();
    return _db!;
  }

  /// Tests only: use an already opened database as the singleton.
  static void useDatabaseForTesting(Database db) => _db = db;

  /// Tests only: close and forget the singleton.
  static Future<void> resetForTesting() async {
    await _db?.close();
    _db = null;
  }

  Future<Database> _initDatabase() async {
    final path = join(await getDatabasesPath(), fileName);
    return openAtPath(path);
  }

  /// Opens (and creates/upgrades) the database at [path].
  static Future<Database> openAtPath(String path) {
    return openDatabase(
      path,
      version: schemaVersion,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  // ── create / upgrade ──────────────────────────────────────────────────────
  static Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE transactions (
        id TEXT PRIMARY KEY,
        type TEXT NOT NULL,
        category TEXT NOT NULL,
        amount REAL NOT NULL,
        note TEXT,
        date TEXT NOT NULL,
        icon TEXT NOT NULL,
        sourceId TEXT
      )
    ''');
    await _createV2Tables(db);
    // Fresh install: nothing to migrate from SharedPreferences for debt, but
    // MigrationService still decides that (it checks for old data first).
  }

  static Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    // Incremental: run every step between the old and the new version.
    for (var v = oldVersion + 1; v <= newVersion; v++) {
      switch (v) {
        case 2:
          await _migrateTo2(db);
          break;
        default:
          throw StateError('Missing migration to version $v');
      }
    }
  }

  /// v1 → v2. Additive only; never drops or rewrites existing data.
  static Future<void> _migrateTo2(Database db) async {
    await db.execute('ALTER TABLE transactions ADD COLUMN sourceId TEXT');
    await _createV2Tables(db);
  }

  static Future<void> _createV2Tables(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS categories (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        icon TEXT NOT NULL,
        type TEXT NOT NULL,
        position INTEGER NOT NULL DEFAULT 0
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS debt_persons (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        phone TEXT NOT NULL DEFAULT '',
        imagePath TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS debt_transactions (
        id TEXT PRIMARY KEY,
        personId TEXT NOT NULL,
        amount REAL NOT NULL,
        type TEXT NOT NULL,
        date TEXT NOT NULL,
        note TEXT NOT NULL DEFAULT '',
        FOREIGN KEY (personId) REFERENCES debt_persons(id) ON DELETE CASCADE
      )
    ''');
    await db.execute('''
      CREATE TABLE IF NOT EXISTS app_meta (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
      )
    ''');
    await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_tx_date ON transactions(date)');
    await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_tx_source ON transactions(sourceId)');
    await db.execute(
        'CREATE INDEX IF NOT EXISTS idx_debt_tx_person ON debt_transactions(personId)');
  }

  // ── meta flags ────────────────────────────────────────────────────────────
  Future<String?> getMeta(String key) async {
    final db = await database;
    final rows = await db.query('app_meta', where: 'key = ?', whereArgs: [key]);
    return rows.isEmpty ? null : rows.first['value'] as String;
  }

  Future<void> setMeta(String key, String value) async {
    final db = await database;
    await db.insert('app_meta', {'key': key, 'value': value},
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  // ── transactions (existing API kept) ──────────────────────────────────────
  Future<List<model.Transaction>> getAllTransactions() async {
    final db = await database;
    final maps = await db.query('transactions', orderBy: 'date DESC');
    return maps.map(model.Transaction.fromJson).toList();
  }

  Future<void> insertTransaction(model.Transaction tx) async {
    final db = await database;
    await db.insert('transactions', tx.toJson(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> updateTransaction(model.Transaction tx) async {
    final db = await database;
    await db.update('transactions', tx.toJson(),
        where: 'id = ?', whereArgs: [tx.id]);
  }

  Future<void> deleteTransaction(String id) async {
    final db = await database;
    await db.delete('transactions', where: 'id = ?', whereArgs: [id]);
  }

  /// True if the STORED row [id] was generated from a debt transaction. Used as the
  /// authoritative check so a stale in-memory copy can never bypass the protection.
  Future<bool> isDebtLinkedTransaction(String id) async {
    final db = await database;
    final rows = await db.query('transactions',
        columns: ['sourceId'], where: 'id = ?', whereArgs: [id], limit: 1);
    return rows.isNotEmpty && rows.first['sourceId'] != null;
  }

  /// Kept for compatibility. Prefer BackupService.restore (atomic, validated).
  Future<void> deleteAll() async {
    final db = await database;
    await db.delete('transactions');
  }

  Future<void> insertAll(List<model.Transaction> txs) async {
    final db = await database;
    final batch = db.batch();
    for (final tx in txs) {
      batch.insert('transactions', tx.toJson(),
          conflictAlgorithm: ConflictAlgorithm.replace);
    }
    await batch.commit(noResult: true);
  }

  // ── categories (plain rows; AppCategory lives in presentation code) ───────
  Future<List<Map<String, Object?>>> getCategoryRows() async {
    final db = await database;
    return db.query('categories', orderBy: 'position ASC, rowid ASC');
  }

  Future<void> insertCategoryRow(Map<String, Object?> row) async {
    final db = await database;
    final next = Sqflite.firstIntValue(
            await db.rawQuery('SELECT COALESCE(MAX(position), -1) + 1 FROM categories')) ??
        0;
    await db.insert('categories', {...row, 'position': row['position'] ?? next},
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<void> updateCategoryRow(String id, String name, String icon) async {
    final db = await database;
    await db.update('categories', {'name': name, 'icon': icon},
        where: 'id = ?', whereArgs: [id]);
  }

  Future<void> deleteCategoryRow(String id) async {
    final db = await database;
    await db.delete('categories', where: 'id = ?', whereArgs: [id]);
  }

  // ── debt ──────────────────────────────────────────────────────────────────
  Future<List<DebtPerson>> getAllPersons() async {
    final db = await database;
    final rows = await db.query('debt_persons', orderBy: 'rowid ASC');
    return rows.map(DebtPerson.fromJson).toList();
  }

  Future<List<DebtTransaction>> getAllDebtTransactions() async {
    final db = await database;
    final rows = await db.query('debt_transactions', orderBy: 'rowid ASC');
    return rows.map(DebtTransaction.fromJson).toList();
  }

  Future<void> insertPerson(DebtPerson p) async {
    final db = await database;
    await db.insert('debt_persons', p.toJson(),
        conflictAlgorithm: ConflictAlgorithm.abort);
  }

  Future<void> updatePerson(DebtPerson p) async {
    final db = await database;
    await db.update('debt_persons', p.toJson(),
        where: 'id = ?', whereArgs: [p.id]);
  }

  /// Inserts a debt transaction and (optionally) its mirror ledger entry in
  /// ONE database transaction: both are saved or neither is.
  Future<void> insertDebtTransaction(DebtTransaction t,
      {model.Transaction? mirror}) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.insert('debt_transactions', t.toJson(),
          conflictAlgorithm: ConflictAlgorithm.abort);
      if (mirror != null) {
        await txn.insert('transactions', mirror.toJson(),
            conflictAlgorithm: ConflictAlgorithm.abort);
      }
    });
  }

  /// Deletes a debt transaction and the ledger entry generated from it.
  Future<void> deleteDebtTransaction(String id) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.delete('transactions', where: 'sourceId = ?', whereArgs: [id]);
      await txn.delete('debt_transactions', where: 'id = ?', whereArgs: [id]);
    });
  }

  Future<PersonDeletionSummary> getPersonDeletionSummary(String personId) async {
    final db = await database;
    final rows = await db.rawQuery('''
      SELECT COUNT(*) AS c,
             COALESCE(SUM(CASE type WHEN 'gave' THEN amount ELSE -amount END), 0) AS bal
      FROM debt_transactions WHERE personId = ?
    ''', [personId]);
    final linked = Sqflite.firstIntValue(await db.rawQuery('''
      SELECT COUNT(*) FROM transactions
      WHERE sourceId IN (SELECT id FROM debt_transactions WHERE personId = ?)
    ''', [personId])) ??
        0;
    final r = rows.first;
    return PersonDeletionSummary(
      debtTransactionCount: (r['c'] as num).toInt(),
      balance: (r['bal'] as num).toDouble(),
      linkedLedgerCount: linked,
    );
  }

  /// Deletes a person together with ALL of their debt transactions (and the
  /// ledger entries generated from them) atomically. If any step fails the
  /// whole operation is rolled back.
  Future<void> deletePersonCascade(String personId) async {
    final db = await database;
    await db.transaction((txn) async {
      await txn.rawDelete('''
        DELETE FROM transactions
        WHERE sourceId IN (SELECT id FROM debt_transactions WHERE personId = ?)
      ''', [personId]);
      // Explicit even though the FK would cascade, so behaviour does not
      // depend on the PRAGMA being active.
      await txn.delete('debt_transactions',
          where: 'personId = ?', whereArgs: [personId]);
      final n = await txn
          .delete('debt_persons', where: 'id = ?', whereArgs: [personId]);
      if (n != 1) {
        throw StateError('person not found'); // forces rollback
      }
    });
  }
}
