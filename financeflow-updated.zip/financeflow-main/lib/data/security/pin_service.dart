// lib/data/security/pin_service.dart
//
// PIN storage, verification and migration.
//
// Storage
//   • The PIN itself is never stored. A salted PBKDF2-HMAC-SHA256 hash is kept
//     in Keystore-backed secure storage under 'pin_hash_v1'.
//   • SharedPreferences only holds non-secret state: 'pin_enabled' (existing),
//     'lock_timeout_seconds', and the wrong-attempt counters.
//   • Honest limit: a 4-digit PIN has only 10,000 values, so no hash can stop
//     someone who obtains the hash AND can run offline guesses. The protection
//     comes from (1) the hash living in the Keystore-backed store, not in a
//     readable preferences file, and (2) attempt throttling below.
//
// Legacy migration (plain-text 'app_pin' in SharedPreferences)
//   • Eager: at app start, the old PIN is hashed, written to secure storage,
//     READ BACK AND VERIFIED, and only then is 'app_pin' removed.
//   • Lazy fallback: if eager migration could not complete (secure storage
//     unavailable), verify() still accepts the legacy PIN and retries the
//     migration after a successful unlock. The user is never locked out by
//     the migration; 'app_pin' is never deleted before the hash is verified.
//
// Never log or return the PIN or hash from this file.

import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../core/app_log.dart';
import 'lock_timeout.dart';
import 'secret_store.dart';

enum PinOutcome {
  /// PIN correct.
  ok,

  /// PIN wrong ([PinVerifyResult.blockedFor] is set when this attempt triggered a delay).
  wrong,

  /// Too many wrong attempts; try again after [PinVerifyResult.blockedFor].
  throttled,

  /// PIN lock is on but no credential exists anywhere (e.g. data restored to a
  /// new phone without the Keystore). The caller should reset the lock.
  credentialMissing,

  /// Secure storage could not be read right now. Retry; do NOT bypass.
  unavailable,
}

class PinVerifyResult {
  final PinOutcome outcome;
  final Duration? blockedFor;
  const PinVerifyResult(this.outcome, [this.blockedFor]);
  bool get isOk => outcome == PinOutcome.ok;
}

enum LegacyMigration {
  /// No legacy plain-text PIN present.
  none,

  /// Hashed, verified, and the plain-text copy removed.
  migrated,

  /// Could not complete safely; legacy PIN left in place and still works.
  deferred,

  /// PIN lock was off, so the leftover plain-text PIN was removed.
  removedStale,
}

class PinException implements Exception {
  final String userMessage;
  PinException(this.userMessage);
  @override
  String toString() => 'PinException';
}

class PinService {
  PinService({SecretStore? store, DateTime Function()? now, int? iterations})
      : _store = store ?? SecureSecretStore(),
        _now = now ?? DateTime.now,
        _iterations = iterations ?? defaultIterations;

  // Preference keys (the first two are unchanged from the original app).
  static const prefEnabled = 'pin_enabled';
  static const prefLegacyPin = 'app_pin';
  static const prefTimeout = 'lock_timeout_seconds';
  static const prefFailCount = 'pin_fail_count';
  static const prefBlockedUntil = 'pin_blocked_until_ms';
  static const secretKey = 'pin_hash_v1';

  static const defaultIterations = 10000;
  static const freeAttempts = 5;
  static const maxDelay = Duration(minutes: 5);

  final SecretStore _store;
  final DateTime Function() _now;
  final int _iterations;

  // ── settings ─────────────────────────────────────────────────────────────
  Future<bool> isEnabled() async {
    final p = await SharedPreferences.getInstance();
    return p.getBool(prefEnabled) ?? false;
  }

  /// Missing value = an existing user who never chose one: keep the old
  /// behaviour (lock only on app start) so the update does not surprise them.
  Future<LockTimeout> loadTimeout() async {
    final p = await SharedPreferences.getInstance();
    return LockTimeout.fromSeconds(p.getInt(prefTimeout));
  }

  Future<void> saveTimeout(LockTimeout t) async {
    final p = await SharedPreferences.getInstance();
    await p.setInt(prefTimeout, t.seconds);
  }

  // ── set / disable ────────────────────────────────────────────────────────
  /// Stores a new PIN. The "enabled" flag is only switched on AFTER the hash
  /// has been written and read back successfully.
  Future<void> setPin(String pin) async {
    if (!RegExp(r'^\d{4}$').hasMatch(pin)) {
      throw PinException('PIN অবশ্যই ৪ সংখ্যার হতে হবে।');
    }
    final record = _PinRecord.create(pin, _iterations);
    try {
      await _store.write(secretKey, record.encode());
      final back = _PinRecord.tryDecode(await _store.read(secretKey));
      if (back == null || !back.matches(pin)) {
        throw StateError('read-back mismatch');
      }
    } catch (e, st) {
      appLog('PinService.setPin', e, st);
      try {
        await _store.delete(secretKey);
      } catch (_) {}
      throw PinException('PIN সেভ করা যায়নি। আবার চেষ্টা করুন।');
    }
    final p = await SharedPreferences.getInstance();
    await p.setBool(prefEnabled, true);
    await p.remove(prefLegacyPin);
    await _resetAttempts(p);
    if (!p.containsKey(prefTimeout)) {
      // New PIN setup gets a sensible default; existing users keep theirs.
      await p.setInt(prefTimeout, LockTimeout.minute1.seconds);
    }
  }

  Future<void> disable() async {
    final p = await SharedPreferences.getInstance();
    await p.setBool(prefEnabled, false);
    await p.remove(prefLegacyPin);
    await _resetAttempts(p);
    try {
      await _store.delete(secretKey);
    } catch (e, st) {
      appLog('PinService.disable', e, st); // stale hash is harmless while disabled
    }
  }

  // ── verify ───────────────────────────────────────────────────────────────
  Future<PinVerifyResult> verify(String pin) async {
    final p = await SharedPreferences.getInstance();

    final until = p.getInt(prefBlockedUntil);
    if (until != null) {
      final left = DateTime.fromMillisecondsSinceEpoch(until).difference(_now());
      if (left > Duration.zero) {
        return PinVerifyResult(PinOutcome.throttled, left);
      }
    }

    String? raw;
    var readFailed = false;
    try {
      raw = await _store.read(secretKey);
    } catch (e, st) {
      readFailed = true;
      appLog('PinService.verify.read', e, st);
    }
    final record = _PinRecord.tryDecode(raw);
    final storedLegacy = p.getString(prefLegacyPin);
    // Non-null only when a usable legacy PIN exists (lets the compiler promote it).
    final legacy =
        (storedLegacy != null && storedLegacy.isNotEmpty) ? storedLegacy : null;
    final hasLegacy = legacy != null;

    var ok = false;
    var viaRecord = false;
    if (record != null && record.matches(pin)) {
      ok = true;
      viaRecord = true;
    } else if (legacy != null && _constantTimeEquals(legacy, pin)) {
      ok = true; // lock-out protection: the old PIN keeps working
    }

    if (ok) {
      await _resetAttempts(p);
      if (viaRecord && hasLegacy) {
        await p.remove(prefLegacyPin); // hash verified, plain copy not needed
      } else if (!viaRecord) {
        await _tryMigrate(pin, p); // lazy migration after a successful unlock
      }
      return const PinVerifyResult(PinOutcome.ok);
    }

    if (record == null && !hasLegacy) {
      return PinVerifyResult(
          readFailed ? PinOutcome.unavailable : PinOutcome.credentialMissing);
    }

    final count = (p.getInt(prefFailCount) ?? 0) + 1;
    await p.setInt(prefFailCount, count);
    if (count >= freeAttempts) {
      final exp = min(count - freeAttempts, 10); // cap: avoid int overflow
      final secs = min(30 * (1 << exp), maxDelay.inSeconds);
      final delay = Duration(seconds: secs);
      await p.setInt(prefBlockedUntil, _now().add(delay).millisecondsSinceEpoch);
      return PinVerifyResult(PinOutcome.wrong, delay);
    }
    return const PinVerifyResult(PinOutcome.wrong);
  }

  /// Used when [PinOutcome.credentialMissing] is reported: nothing can ever
  /// unlock the app, so the lock is switched off and the user must set a new PIN.
  Future<void> resetBrokenLock() => disable();

  // ── legacy migration ─────────────────────────────────────────────────────
  Future<LegacyMigration> migrateLegacyIfNeeded() async {
    final p = await SharedPreferences.getInstance();
    final legacy = p.getString(prefLegacyPin);
    if (legacy == null) return LegacyMigration.none;

    if (!(p.getBool(prefEnabled) ?? false)) {
      await p.remove(prefLegacyPin);
      return LegacyMigration.removedStale;
    }
    if (legacy.isEmpty) return LegacyMigration.deferred;

    // A valid hash already present: only delete the plain copy if they agree.
    try {
      final existing = _PinRecord.tryDecode(await _store.read(secretKey));
      if (existing != null) {
        if (existing.matches(legacy)) {
          await p.remove(prefLegacyPin);
          return LegacyMigration.migrated;
        }
        return LegacyMigration.deferred; // disagree: keep both, accept either
      }
    } catch (e, st) {
      appLog('PinService.migrate.read', e, st);
      return LegacyMigration.deferred;
    }
    return await _tryMigrate(legacy, p) ? LegacyMigration.migrated : LegacyMigration.deferred;
  }

  /// Hash → write → read back → verify → only then remove the plain PIN.
  /// Never throws; on any failure the legacy PIN stays untouched.
  Future<bool> _tryMigrate(String plain, SharedPreferences p) async {
    try {
      final record = _PinRecord.create(plain, _iterations);
      await _store.write(secretKey, record.encode());
      final back = _PinRecord.tryDecode(await _store.read(secretKey));
      if (back == null || !back.matches(plain)) return false;
      await p.remove(prefLegacyPin);
      return true;
    } catch (e, st) {
      appLog('PinService.tryMigrate', e, st);
      return false;
    }
  }

  Future<void> _resetAttempts(SharedPreferences p) async {
    await p.remove(prefFailCount);
    await p.remove(prefBlockedUntil);
  }
}

// ── hashing ────────────────────────────────────────────────────────────────

/// PBKDF2-HMAC-SHA256, 32-byte output (a single block, so no block loop).
List<int> pbkdf2Sha256(List<int> password, List<int> salt, int iterations) {
  final hmac = Hmac(sha256, password);
  var u = hmac.convert([...salt, 0, 0, 0, 1]).bytes;
  final t = List<int>.from(u);
  for (var i = 1; i < iterations; i++) {
    u = hmac.convert(u).bytes;
    for (var j = 0; j < t.length; j++) {
      t[j] ^= u[j];
    }
  }
  return t;
}

bool _constantTimeEquals(String a, String b) {
  final x = utf8.encode(a), y = utf8.encode(b);
  var diff = x.length ^ y.length;
  for (var i = 0; i < x.length && i < y.length; i++) {
    diff |= x[i] ^ y[i];
  }
  return diff == 0;
}

bool _constantTimeBytes(List<int> a, List<int> b) {
  var diff = a.length ^ b.length;
  for (var i = 0; i < a.length && i < b.length; i++) {
    diff |= a[i] ^ b[i];
  }
  return diff == 0;
}

class _PinRecord {
  final int iterations;
  final List<int> salt;
  final List<int> hash;
  _PinRecord(this.iterations, this.salt, this.hash);

  factory _PinRecord.create(String pin, int iterations) {
    final rnd = Random.secure();
    final salt = List<int>.generate(16, (_) => rnd.nextInt(256));
    return _PinRecord(iterations, salt, pbkdf2Sha256(utf8.encode(pin), salt, iterations));
  }

  bool matches(String pin) =>
      _constantTimeBytes(pbkdf2Sha256(utf8.encode(pin), salt, iterations), hash);

  String encode() => jsonEncode({
        'v': 1,
        'iter': iterations,
        'salt': base64Encode(salt),
        'hash': base64Encode(hash),
      });

  /// null for missing or malformed data (treated as "no credential").
  static _PinRecord? tryDecode(String? raw) {
    if (raw == null || raw.isEmpty) return null;
    try {
      final m = jsonDecode(raw);
      if (m is! Map || m['v'] != 1) return null;
      final iter = m['iter'];
      if (iter is! int || iter < 1 || iter > 1000000) return null;
      final salt = base64Decode(m['salt'] as String);
      final hash = base64Decode(m['hash'] as String);
      if (salt.isEmpty || hash.length != 32) return null;
      return _PinRecord(iter, salt, hash);
    } catch (_) {
      return null;
    }
  }
}
