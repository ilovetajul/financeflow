// lib/data/security/app_lock_controller.dart
//
// Pure (widget-free) lock-state logic so the lifecycle rules can be unit
// tested with a fake clock.
//
// Rules
//  • Cold start with PIN enabled  → locked (unchanged from the original app).
//  • App goes to the background (paused/hidden) → remember the time.
//  • App returns → locked if timeout != never AND time away >= timeout.
//      immediately = any background trip locks, 30s / 1m / 5m = elapsed time.
//  • never → background never locks (only a cold start does).
//  • A brief `inactive` (system dialog, notification shade) is NOT a
//    background trip, so it never locks by itself.
//  • Wall-clock time is used so time spent asleep counts. If the clock was set
//    backwards (negative elapsed time) the app locks: fail safe.

import 'lock_timeout.dart';

class AppLockController {
  AppLockController({DateTime Function()? now}) : _now = now ?? DateTime.now;

  final DateTime Function() _now;

  bool pinEnabled = false;
  LockTimeout timeout = LockTimeout.never;

  bool _locked = false;
  bool get locked => _locked;

  /// The security settings could not be read, so whether a PIN exists is unknown.
  /// The controller then stays locked (fail closed) until they can be read again.
  bool _settingsUnavailable = false;
  bool get settingsUnavailable => _settingsUnavailable;

  DateTime? _leftAt;
  bool get isInBackground => _leftAt != null;

  /// Cold start.
  void start({
    required bool pinEnabled,
    required LockTimeout timeout,
    bool settingsUnavailable = false,
  }) {
    this.pinEnabled = pinEnabled;
    this.timeout = timeout;
    _settingsUnavailable = settingsUnavailable;
    _locked = pinEnabled || settingsUnavailable;
    _leftAt = null;
  }

  /// Settings changed while running (PIN turned on/off, timeout changed).
  void updateSettings({bool? pinEnabled, LockTimeout? timeout, bool? settingsUnavailable}) {
    if (settingsUnavailable == true) {
      // Settings could not be read: lock now and stay locked until they can be.
      _settingsUnavailable = true;
      _locked = true;
      _leftAt = null;
      return;
    }
    if (settingsUnavailable == false && _settingsUnavailable) {
      // Recovered: behave like a cold start with the freshly read settings.
      _settingsUnavailable = false;
      if (pinEnabled != null) this.pinEnabled = pinEnabled;
      if (timeout != null) this.timeout = timeout;
      _locked = this.pinEnabled;
      _leftAt = null;
      return;
    }
    if (pinEnabled != null) this.pinEnabled = pinEnabled;
    if (timeout != null) this.timeout = timeout;
    if (!this.pinEnabled) {
      _locked = false;
      _leftAt = null;
    }
  }

  /// App moved to the background (paused / hidden).
  void onBackground() {
    if (!pinEnabled) {
      _leftAt = null;
      return;
    }
    _leftAt ??= _now();
  }

  /// App came back. Returns whether the app is locked afterwards.
  bool onForeground() {
    final left = _leftAt;
    _leftAt = null;
    if (_settingsUnavailable) return true; // fail closed
    if (!pinEnabled) {
      _locked = false;
      return false;
    }
    if (left == null || _locked) return _locked;
    final limit = timeout.duration;
    if (limit == null) return _locked; // never
    final away = _now().difference(left);
    if (away.isNegative || away >= limit) _locked = true;
    return _locked;
  }

  void unlock() {
    if (_settingsUnavailable) return; // a PIN cannot unlock an unknown security state
    _locked = false;
    _leftAt = null;
  }
}
