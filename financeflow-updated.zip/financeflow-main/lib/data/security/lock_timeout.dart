// lib/data/security/lock_timeout.dart

/// How long the app may stay in the background before the PIN is required
/// again when the user returns.
enum LockTimeout {
  immediately(0),
  seconds30(30),
  minute1(60),
  minutes5(300),
  never(-1);

  /// Value persisted in SharedPreferences ('lock_timeout_seconds').
  final int seconds;
  const LockTimeout(this.seconds);

  /// null for [never].
  Duration? get duration => this == never ? null : Duration(seconds: seconds);

  String get label {
    switch (this) {
      case LockTimeout.immediately:
        return 'সাথে সাথে';
      case LockTimeout.seconds30:
        return '৩০ সেকেন্ড';
      case LockTimeout.minute1:
        return '১ মিনিট';
      case LockTimeout.minutes5:
        return '৫ মিনিট';
      case LockTimeout.never:
        return 'কখনো না';
    }
  }

  /// Unknown / missing values map to [fallback].
  static LockTimeout fromSeconds(int? s, {LockTimeout fallback = LockTimeout.never}) {
    for (final t in LockTimeout.values) {
      if (t.seconds == s) return t;
    }
    return fallback;
  }
}
