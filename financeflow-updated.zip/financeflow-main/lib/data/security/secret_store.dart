// lib/data/security/secret_store.dart
//
// Abstraction over a hardware-backed secret store so PIN logic can be tested
// without a device.

import 'package:flutter_secure_storage/flutter_secure_storage.dart';

abstract class SecretStore {
  /// Returns null when the key does not exist. Throws when the store itself
  /// cannot be read (e.g. Keystore problem).
  Future<String?> read(String key);
  Future<void> write(String key, String value);
  Future<void> delete(String key);
}

/// Android Keystore-backed storage (flutter_secure_storage).
class SecureSecretStore implements SecretStore {
  SecureSecretStore([FlutterSecureStorage? storage])
      : _s = storage ?? const FlutterSecureStorage();
  final FlutterSecureStorage _s;

  @override
  Future<String?> read(String key) => _s.read(key: key);
  @override
  Future<void> write(String key, String value) => _s.write(key: key, value: value);
  @override
  Future<void> delete(String key) => _s.delete(key: key);
}
