// lib/domain/default_categories.dart
//
// Seed categories for a fresh install (and for upgrades where the user never
// customised categories). Kept as plain maps so the data layer does not depend
// on presentation code. Ids are stable so backups can be merged by id.

const List<Map<String, String>> kDefaultCategoryRows = [
  {'id': 'i1', 'name': 'বেতন',           'icon': '💼', 'type': 'income'},
  {'id': 'i2', 'name': 'ফ্রিল্যান্স',   'icon': '💻', 'type': 'income'},
  {'id': 'i3', 'name': 'বিনিয়োগ',      'icon': '📈', 'type': 'income'},
  {'id': 'i4', 'name': 'বোনাস',          'icon': '🎁', 'type': 'income'},
  {'id': 'i5', 'name': 'ব্যক্তিগত আয়', 'icon': '💰', 'type': 'income'},
  {'id': 'e1', 'name': 'বাড়িভাড়া',    'icon': '🏠', 'type': 'expense'},
  {'id': 'e2', 'name': 'বাজার',          'icon': '🛒', 'type': 'expense'},
  {'id': 'e3', 'name': 'বিল',            'icon': '⚡', 'type': 'expense'},
  {'id': 'e4', 'name': 'যাতায়াত',      'icon': '🚗', 'type': 'expense'},
  {'id': 'e5', 'name': 'খাবার',          'icon': '🍜', 'type': 'expense'},
  {'id': 'e6', 'name': 'স্বাস্থ্য',    'icon': '💊', 'type': 'expense'},
  {'id': 'e7', 'name': 'শিক্ষা',         'icon': '📚', 'type': 'expense'},
  {'id': 'e8', 'name': 'বিনোদন',        'icon': '🎬', 'type': 'expense'},
  {'id': 'e9', 'name': 'ব্যক্তিগত খরচ', 'icon': '💳', 'type': 'expense'},
];
