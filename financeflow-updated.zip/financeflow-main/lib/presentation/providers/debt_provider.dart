// lib/presentation/providers/debt_provider.dart
//
// Debt data now lives in SQLite (tables debt_persons / debt_transactions).
// State lists are reloaded from the database after every change, so balances
// are always derived from the stored transaction history, never from cached
// totals.
//
// Terminology (used consistently across the app):
//   DebtType.gave     = আমি দিয়েছি  → money I GAVE   → they owe me (পাওনা)
//   DebtType.received = আমি পেয়েছি  → money I RECEIVED → I owe them (দেনা)
//   net = gave − received   (>0: receivable, <0: payable)

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';
import '../../core/app_log.dart';
import '../../data/local/database_helper.dart';
import '../../domain/models/debt_model.dart';
import '../../domain/models/transaction.dart';
import 'transaction_provider.dart';

/// Category name used for ledger entries generated from debt transactions.
const String kDebtLedgerCategory = 'দেনা-পাওনা';

// ── Persons provider ─────────────────────────────────────────
class DebtPersonNotifier extends StateNotifier<List<DebtPerson>> {
  DebtPersonNotifier(this._ref) : super([]) { reload(); }

  final Ref _ref;
  final _db = DatabaseHelper.instance;

  Future<void> reload() async {
    try {
      state = await _db.getAllPersons();
    } catch (e, st) {
      appLog('DebtPersonNotifier.reload', e, st);
    }
  }

  Future<void> addPerson(DebtPerson person) async {
    await _db.insertPerson(person);
    await reload();
  }

  Future<void> updatePerson(DebtPerson person) async {
    await _db.updatePerson(person);
    await reload();
  }

  /// What deleting [personId] would remove (shown in the confirmation dialog).
  Future<PersonDeletionSummary> deletionSummary(String personId) =>
      _db.getPersonDeletionSummary(personId);

  /// Deletes the person, ALL their debt transactions and the ledger entries
  /// generated from them, atomically; then refreshes every dependent provider.
  Future<void> deletePerson(String id) async {
    await _db.deletePersonCascade(id);
    await reload();
    await _ref.read(debtTransactionsProvider.notifier).reload();
    _ref.invalidate(transactionsProvider);
  }
}

final debtPersonsProvider =
    StateNotifierProvider<DebtPersonNotifier, List<DebtPerson>>(
        (ref) => DebtPersonNotifier(ref));

// ── Debt transactions provider ───────────────────────────────
class DebtTransactionNotifier extends StateNotifier<List<DebtTransaction>> {
  DebtTransactionNotifier(this._ref) : super([]) { reload(); }

  final Ref _ref;
  final _db = DatabaseHelper.instance;

  Future<void> reload() async {
    try {
      state = await _db.getAllDebtTransactions();
    } catch (e, st) {
      appLog('DebtTransactionNotifier.reload', e, st);
    }
  }

  /// Adds a debt transaction. With [affectMain] a linked income/expense entry
  /// is created in the main ledger in the SAME database transaction.
  Future<void> add(DebtTransaction tx, {bool affectMain = false}) async {
    Transaction? mirror;
    if (affectMain) {
      final gave = tx.type == DebtType.gave;
      mirror = Transaction(
        id: const Uuid().v4(),
        type: gave ? TransactionType.expense : TransactionType.income,
        category: kDebtLedgerCategory,
        amount: tx.amount,
        note: tx.note,
        date: tx.date,
        icon: gave ? '💸' : '💰',
        sourceId: tx.id,
      );
    }
    await _db.insertDebtTransaction(tx, mirror: mirror);
    await reload();
    if (affectMain) _ref.invalidate(transactionsProvider);
  }

  /// Deletes the debt transaction and the ledger entry generated from it.
  Future<void> delete(String id) async {
    await _db.deleteDebtTransaction(id);
    await reload();
    _ref.invalidate(transactionsProvider);
  }

  List<DebtTransaction> forPerson(String personId) =>
      state.where((t) => t.personId == personId).toList()
        ..sort((a, b) => b.date.compareTo(a.date));

  // Positive = person owes me, Negative = I owe person
  double netForPerson(String personId) => forPerson(personId).fold(
      0.0, (sum, t) => t.type == DebtType.gave ? sum + t.amount : sum - t.amount);
}

final debtTransactionsProvider =
    StateNotifierProvider<DebtTransactionNotifier, List<DebtTransaction>>(
        (ref) => DebtTransactionNotifier(ref));

// ── Helper: net balance per person ───────────────────────────
final personNetProvider = Provider.family<double, String>((ref, personId) {
  final txs = ref.watch(debtTransactionsProvider);
  return txs
      .where((t) => t.personId == personId)
      .fold(0.0, (sum, t) => t.type == DebtType.gave ? sum + t.amount : sum - t.amount);
});

/// Per-person net balances (personId → gave − received).
final personNetsProvider = Provider<Map<String, double>>((ref) {
  final txs = ref.watch(debtTransactionsProvider);
  final m = <String, double>{};
  for (final t in txs) {
    m[t.personId] =
        (m[t.personId] ?? 0) + (t.type == DebtType.gave ? t.amount : -t.amount);
  }
  return m;
});

/// Total receivable (পাওনা): sum of positive per-person balances.
final totalReceivableProvider = Provider<double>((ref) => ref
    .watch(personNetsProvider)
    .values
    .where((v) => v > 0)
    .fold(0.0, (s, v) => s + v));

/// Total payable (দেনা): sum of negative per-person balances, as a positive number.
final totalPayableProvider = Provider<double>((ref) => ref
    .watch(personNetsProvider)
    .values
    .where((v) => v < 0)
    .fold(0.0, (s, v) => s - v));

// ── Net debt across all persons (kept name; positive = net owed to me) ──
final totalOwedToMeProvider = Provider<double>((ref) {
  final txs = ref.watch(debtTransactionsProvider);
  return txs.fold(0.0, (sum, t) => t.type == DebtType.gave ? sum + t.amount : sum - t.amount);
});
