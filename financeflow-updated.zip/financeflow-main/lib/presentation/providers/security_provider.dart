// lib/presentation/providers/security_provider.dart

import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/app_log.dart';
import '../../data/security/lock_timeout.dart';
import '../../data/security/pin_service.dart';

/// Overridable in tests (fake secret store / fast hashing).
final pinServiceProvider = Provider<PinService>((ref) => PinService());

/// Overridable clock for lifecycle tests.
final appLockClockProvider =
    Provider<DateTime Function()>((ref) => DateTime.now);

class LockSettings {
  final bool pinEnabled;
  final LockTimeout timeout;

  /// True when the security settings could not be read. The values above are then
  /// NOT trustworthy (in particular `pinEnabled == false` does not mean "no PIN"),
  /// and the app must stay locked (fail closed).
  final bool loadFailed;

  const LockSettings({
    this.pinEnabled = false,
    this.timeout = LockTimeout.never,
    this.loadFailed = false,
  });
}

/// Source of truth for the lock layer: whether a PIN is on and the timeout.
class LockSettingsNotifier extends StateNotifier<LockSettings> {
  LockSettingsNotifier(this._pins) : super(const LockSettings());
  final PinService _pins;

  /// Reads the settings. Returns false if they could not be read; in that case the
  /// state is marked [LockSettings.loadFailed] (the last known values are kept but
  /// must not be trusted) so the lock layer fails CLOSED instead of assuming
  /// "PIN disabled".
  Future<bool> reload() async {
    try {
      final enabled = await _pins.isEnabled();
      final timeout = await _pins.loadTimeout();
      if (!mounted) return true;
      state = LockSettings(pinEnabled: enabled, timeout: timeout);
      return true;
    } catch (e, st) {
      appLog('LockSettingsNotifier.reload', e, st);
      if (mounted) {
        state = LockSettings(
            pinEnabled: state.pinEnabled, timeout: state.timeout, loadFailed: true);
      }
      return false;
    }
  }

  Future<void> setTimeout(LockTimeout t) async {
    await _pins.saveTimeout(t);
    if (!mounted) return;
    state = LockSettings(pinEnabled: state.pinEnabled, timeout: t);
  }
}

final lockSettingsProvider =
    StateNotifierProvider<LockSettingsNotifier, LockSettings>(
        (ref) => LockSettingsNotifier(ref.watch(pinServiceProvider)));
