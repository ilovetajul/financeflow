// lib/presentation/debt_linked_guard.dart
import 'package:flutter/material.dart';
import '../domain/models/transaction.dart';
import 'providers/transaction_provider.dart' show kDebtLinkedMessage;

/// For `Dismissible.confirmDismiss` and similar entry points. If [tx] was
/// generated from a debt transaction, tells the user why it cannot be changed
/// here and returns true (= blocked). Returns false for ordinary transactions.
bool blockIfDebtLinked(BuildContext context, Transaction tx) {
  if (!tx.isDebtLinked) return false;
  ScaffoldMessenger.of(context)
      .showSnackBar(const SnackBar(content: Text(kDebtLinkedMessage)));
  return true;
}
