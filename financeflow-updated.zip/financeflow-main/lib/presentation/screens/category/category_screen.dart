// lib/presentation/screens/category/category_screen.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/app_log.dart';
import '../../../data/local/database_helper.dart';
import '../../../app/theme.dart';
import '../../providers/transaction_provider.dart';
import '../../debt_linked_guard.dart';
import '../../../domain/models/transaction.dart';

// ── Model ─────────────────────────────────────────────────────────
class AppCategory {
  final String id;
  final String name;
  final String icon;
  final TransactionType type;

  AppCategory({required this.id, required this.name, required this.icon, required this.type});

  Map<String, dynamic> toJson() =>
      {'id': id, 'name': name, 'icon': icon, 'type': type.name};

  factory AppCategory.fromJson(Map<String, dynamic> j) => AppCategory(
        id: j['id'] as String,
        name: j['name'] as String,
        icon: j['icon'] as String,
        type: TransactionType.values.byName(j['type'] as String),
      );
}

// ── Provider (backed by SQLite `categories` table) ─────────────────
// Default categories are seeded once by MigrationService on first launch of
// schema v2 (see lib/domain/default_categories.dart).
class CategoryNotifier extends StateNotifier<List<AppCategory>> {
  CategoryNotifier() : super([]) { load(); }

  final _db = DatabaseHelper.instance;

  Future<void> load() async {
    try {
      final rows = await _db.getCategoryRows();
      state = rows.map(AppCategory.fromJson).toList();
    } catch (e, st) {
      appLog('CategoryNotifier.load', e, st);
    }
  }

  Future<void> add(AppCategory cat) async {
    await _db.insertCategoryRow(cat.toJson());
    await load();
  }

  Future<void> remove(String id) async {
    await _db.deleteCategoryRow(id);
    await load();
  }

  Future<void> edit(String id, String newName, String newIcon) async {
    await _db.updateCategoryRow(id, newName, newIcon);
    await load();
  }
}

final categoriesProvider =
    StateNotifierProvider<CategoryNotifier, List<AppCategory>>(
        (ref) => CategoryNotifier());

// ── Icons ──────────────────────────────────────────────────────────
const _icons = [
  '💰','💳','🏦','📊','💎','🎯','🏪','🎪',
  '🏠','🛒','⚡','🚗','🍜','💊','📚','🎬',
  '✈️','👔','🎮','🏋️','🐾','🌿','🎵','📱',
  '🧴','👶','🎓','🏥','🔧','🍕','☕','🧹',
];

// ══════════════════════════════════════════════════════════════════
// CATEGORY SCREEN
// ══════════════════════════════════════════════════════════════════
class CategoryScreen extends ConsumerStatefulWidget {
  const CategoryScreen({super.key});
  @override
  ConsumerState<CategoryScreen> createState() => _CategoryScreenState();
}

class _CategoryScreenState extends ConsumerState<CategoryScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tab;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
    _tab.addListener(() => setState(() {}));
  }

  @override
  void dispose() { _tab.dispose(); super.dispose(); }

  void _showAdd(TransactionType type) {
    final ctrl = TextEditingController();
    String sel = '💰';
    showModalBottomSheet(
      context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(builder: (ctx2, setS) => _sheet(
        title: type == TransactionType.income ? '↑ নতুন আয়ের Category' : '↓ নতুন খরচের Category',
        ctrl: ctrl, selIcon: sel, type: type,
        onIconTap: (ic) => setS(() => sel = ic),
        onSave: () {
          if (ctrl.text.trim().isEmpty) return;
          ref.read(categoriesProvider.notifier).add(AppCategory(
            id: DateTime.now().millisecondsSinceEpoch.toString(),
            name: ctrl.text.trim(), icon: sel, type: type));
          Navigator.pop(ctx2);
          _snack('✅ "${ctrl.text.trim()}" যোগ হয়েছে!', AppColors.teal);
        },
        onCancel: () => Navigator.pop(ctx2),
      )));
  }

  void _showEdit(AppCategory cat) {
    final ctrl = TextEditingController(text: cat.name);
    String sel = cat.icon;
    showModalBottomSheet(
      context: context, isScrollControlled: true, backgroundColor: Colors.transparent,
      builder: (ctx) => StatefulBuilder(builder: (ctx2, setS) => _editSheet(
        cat: cat, ctrl: ctrl, selIcon: sel,
        onIconTap: (ic) => setS(() => sel = ic),
        onSave: () {
          if (ctrl.text.trim().isEmpty) return;
          ref.read(categoriesProvider.notifier).edit(cat.id, ctrl.text.trim(), sel);
          Navigator.pop(ctx2);
          _snack('✅ Category update হয়েছে!', AppColors.gold);
        },
        onDelete: () { Navigator.pop(ctx2); _confirmDelete(cat); },
        onCancel: () => Navigator.pop(ctx2),
      )));
  }

  void _confirmDelete(AppCategory cat) {
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: const Color(0xFF141C2E),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: Row(children: [
        Text(cat.icon, style: const TextStyle(fontSize: 22)), const SizedBox(width: 10),
        const Text('Delete করবে?', style: TextStyle(color: AppColors.textPrimary, fontFamily: 'Syne', fontWeight: FontWeight.w700)),
      ]),
      content: Text('"${cat.name}" category মুছে যাবে।',
          style: const TextStyle(color: AppColors.textMuted, fontSize: 13, height: 1.5)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context),
            child: const Text('না, রাখো', style: TextStyle(color: AppColors.textMuted))),
        ElevatedButton(
          onPressed: () {
            ref.read(categoriesProvider.notifier).remove(cat.id);
            Navigator.pop(context);
            _snack('"${cat.name}" delete হয়েছে', AppColors.rose);
          },
          style: ElevatedButton.styleFrom(backgroundColor: AppColors.rose, foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
          child: const Text('হ্যাঁ, Delete করো')),
      ]));
  }

  void _snack(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      backgroundColor: color, behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      content: Text(msg, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600))));
  }

  @override
  Widget build(BuildContext context) {
    final categories = ref.watch(categoriesProvider);
    final allTxs = ref.watch(transactionsProvider).maybeWhen(data: (t) => t, orElse: () => <Transaction>[]);
    final incCats = categories.where((c) => c.type == TransactionType.income).toList();
    final expCats = categories.where((c) => c.type == TransactionType.expense).toList();
    final isIncome = _tab.index == 0;
    final typeColor = isIncome ? AppColors.teal : AppColors.rose;

    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(child: Column(children: [
        Padding(padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Categories', style: TextStyle(color: AppColors.textPrimary, fontSize: 24, fontWeight: FontWeight.w800, fontFamily: 'Syne')),
              Text('${categories.length} টি · ধরে রাখো = Edit', style: const TextStyle(color: AppColors.textMuted, fontSize: 11)),
            ]),
            GestureDetector(
              onTap: () => _showAdd(isIncome ? TransactionType.income : TransactionType.expense),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                decoration: BoxDecoration(
                  gradient: isIncome ? AppColors.gradTeal : AppColors.gradRose,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [BoxShadow(color: typeColor.withOpacity(0.35), blurRadius: 12, offset: const Offset(0, 4))]),
                child: const Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.add_rounded, color: Colors.white, size: 18), SizedBox(width: 6),
                  Text('নতুন', style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700)),
                ])),
            ),
          ])),
        const SizedBox(height: 16),
        Padding(padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(color: Colors.white.withOpacity(0.04), borderRadius: BorderRadius.circular(14), border: Border.all(color: Colors.white.withOpacity(0.06))),
            child: TabBar(controller: _tab,
              indicator: BoxDecoration(
                gradient: isIncome ? AppColors.gradTeal : AppColors.gradRose,
                borderRadius: BorderRadius.circular(11),
                boxShadow: [BoxShadow(color: typeColor.withOpacity(0.3), blurRadius: 8)]),
              labelColor: Colors.white, unselectedLabelColor: AppColors.textMuted,
              labelStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
              dividerColor: Colors.transparent,
              tabs: [
                Tab(child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  const Text('↑ আয়'), const SizedBox(width: 6),
                  Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(color: Colors.white.withOpacity(0.15), borderRadius: BorderRadius.circular(8)),
                    child: Text('${incCats.length}', style: const TextStyle(fontSize: 11)))])),
                Tab(child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                  const Text('↓ খরচ'), const SizedBox(width: 6),
                  Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(color: Colors.white.withOpacity(0.15), borderRadius: BorderRadius.circular(8)),
                    child: Text('${expCats.length}', style: const TextStyle(fontSize: 11)))])),
              ])),
        ),
        const SizedBox(height: 8),
        Expanded(child: TabBarView(controller: _tab, children: [
          _CatList(cats: incCats, allTxs: allTxs, color: AppColors.teal,
              onAdd: () => _showAdd(TransactionType.income), onEdit: _showEdit),
          _CatList(cats: expCats, allTxs: allTxs, color: AppColors.rose,
              onAdd: () => _showAdd(TransactionType.expense), onEdit: _showEdit),
        ])),
      ])),
    );
  }

  // ── Bottom sheet builders ─────────────────────────────────────
  Widget _iconGrid(String sel, Color borderColor, Function(String) onTap) => SizedBox(
    height: 160,
    child: GridView.builder(
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 8, mainAxisSpacing: 6, crossAxisSpacing: 6),
      itemCount: _icons.length,
      itemBuilder: (_, i) => GestureDetector(
        onTap: () => onTap(_icons[i]),
        child: AnimatedContainer(duration: const Duration(milliseconds: 150),
          decoration: BoxDecoration(
            color: sel == _icons[i] ? borderColor.withOpacity(0.2) : Colors.white.withOpacity(0.06),
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: sel == _icons[i] ? borderColor : Colors.transparent, width: 1.5)),
          child: Center(child: Text(_icons[i], style: const TextStyle(fontSize: 18)))))));

  Widget _sheet({
    required String title, required TextEditingController ctrl, required String selIcon,
    required TransactionType type, required Function(String) onIconTap,
    required VoidCallback onSave, required VoidCallback onCancel,
  }) {
    final color = type == TransactionType.income ? AppColors.teal : AppColors.rose;
    final grad  = type == TransactionType.income ? AppColors.gradTeal : AppColors.gradRose;
    return Container(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      decoration: const BoxDecoration(color: Color(0xFF141C2E), borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(2)))),
        const SizedBox(height: 20),
        Text(title, style: const TextStyle(color: AppColors.textPrimary, fontSize: 18, fontWeight: FontWeight.w800, fontFamily: 'Syne')),
        const SizedBox(height: 20),
        TextField(controller: ctrl, autofocus: true, style: const TextStyle(color: AppColors.textPrimary, fontSize: 15),
          decoration: InputDecoration(hintText: 'Category নাম লেখো', hintStyle: const TextStyle(color: AppColors.textDim, fontSize: 14),
            filled: true, fillColor: Colors.white.withOpacity(0.06),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide(color: color, width: 1.5)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14))),
        const SizedBox(height: 16),
        const Text('Icon বেছে নাও:', style: TextStyle(color: AppColors.textMuted, fontSize: 12, fontWeight: FontWeight.w600)),
        const SizedBox(height: 10),
        _iconGrid(selIcon, color, onIconTap),
        const SizedBox(height: 20),
        GestureDetector(onTap: onSave,
          child: Container(width: double.infinity, height: 52,
            decoration: BoxDecoration(gradient: grad, borderRadius: BorderRadius.circular(14)),
            alignment: Alignment.center,
            child: const Text('Category যোগ করো', style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w800, fontFamily: 'Syne')))),
        const SizedBox(height: 8),
      ])));
  }

  Widget _editSheet({
    required AppCategory cat, required TextEditingController ctrl, required String selIcon,
    required Function(String) onIconTap,
    required VoidCallback onSave, required VoidCallback onDelete, required VoidCallback onCancel,
  }) {
    return Container(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      decoration: const BoxDecoration(color: Color(0xFF141C2E), borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Center(child: Container(width: 40, height: 4, decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(2)))),
        const SizedBox(height: 20),
        Row(children: [
          Text(selIcon, style: const TextStyle(fontSize: 24)), const SizedBox(width: 10),
          const Text('Category Edit করো', style: TextStyle(color: AppColors.textPrimary, fontSize: 18, fontWeight: FontWeight.w800, fontFamily: 'Syne')),
        ]),
        const SizedBox(height: 20),
        TextField(controller: ctrl, autofocus: true, style: const TextStyle(color: AppColors.textPrimary, fontSize: 15),
          decoration: InputDecoration(hintText: 'নতুন নাম লেখো', hintStyle: const TextStyle(color: AppColors.textDim, fontSize: 14),
            filled: true, fillColor: Colors.white.withOpacity(0.06),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
            focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: AppColors.gold, width: 1.5)),
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14))),
        const SizedBox(height: 16),
        const Text('Icon বদলাও:', style: TextStyle(color: AppColors.textMuted, fontSize: 12, fontWeight: FontWeight.w600)),
        const SizedBox(height: 10),
        _iconGrid(selIcon, AppColors.gold, onIconTap),
        const SizedBox(height: 20),
        Row(children: [
          Expanded(child: GestureDetector(onTap: onSave,
            child: Container(height: 50, decoration: BoxDecoration(gradient: AppColors.gradGold, borderRadius: BorderRadius.circular(14)),
              alignment: Alignment.center, child: const Text('সেভ করো', style: TextStyle(color: Color(0xFF0A0E1A), fontSize: 15, fontWeight: FontWeight.w800, fontFamily: 'Syne'))))),
          const SizedBox(width: 10),
          GestureDetector(onTap: onDelete,
            child: Container(height: 50, width: 50,
              decoration: BoxDecoration(color: AppColors.rose.withOpacity(0.15), borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.rose.withOpacity(0.4))),
              child: const Icon(Icons.delete_rounded, color: AppColors.rose, size: 22))),
        ]),
        const SizedBox(height: 8),
      ])));
  }
}

// ── Category list ──────────────────────────────────────────────────
class _CatList extends StatelessWidget {
  final List<AppCategory> cats;
  final List<Transaction> allTxs;
  final Color color;
  final VoidCallback onAdd;
  final Function(AppCategory) onEdit;
  const _CatList({required this.cats, required this.allTxs, required this.color, required this.onAdd, required this.onEdit});

  @override
  Widget build(BuildContext context) {
    if (cats.isEmpty) {
      return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Text('🏷️', style: TextStyle(fontSize: 48)), const SizedBox(height: 16),
        const Text('কোনো Category নেই', style: TextStyle(color: AppColors.textMuted, fontSize: 15)),
        const SizedBox(height: 12),
        GestureDetector(onTap: onAdd,
          child: Container(padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
            decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(12), border: Border.all(color: color.withOpacity(0.3))),
            child: Text('+ নতুন Category যোগ করো', style: TextStyle(color: color, fontSize: 14, fontWeight: FontWeight.w700)))),
      ]));
    }

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
      children: [
        Padding(padding: const EdgeInsets.only(bottom: 8),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.info_outline_rounded, color: AppColors.textDim, size: 12), const SizedBox(width: 4),
            const Text('ট্যাপ = বিস্তারিত · ধরে রাখো = Edit', style: TextStyle(color: AppColors.textDim, fontSize: 11)),
          ])),
        ...cats.map((cat) {
          final catTxs = allTxs.where((t) => t.category == cat.name).toList();
          final total  = catTxs.fold<double>(0, (s, t) => s + t.amount);
          return GestureDetector(
            // ── Tap → Category detail screen ──────────────────────
            onTap: () => Navigator.push(context, MaterialPageRoute(
                builder: (_) => _CatDetailScreen(category: cat, color: color))),
            // ── Long press → Edit ──────────────────────────────────
            onLongPress: () => onEdit(cat),
            child: Container(
              margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: const Color(0xFF141C2E), borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white.withOpacity(0.06))),
              child: Row(children: [
                Container(width: 50, height: 50,
                  decoration: BoxDecoration(color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(15), border: Border.all(color: color.withOpacity(0.25))),
                  child: Center(child: Text(cat.icon, style: const TextStyle(fontSize: 24)))),
                const SizedBox(width: 14),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(cat.name, style: const TextStyle(color: AppColors.textPrimary, fontSize: 14, fontWeight: FontWeight.w700)),
                  Text(catTxs.isEmpty ? 'কোনো লেনদেন নেই' : '${catTxs.length} টি লেনদেন',
                      style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
                ])),
                Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text('৳${total.toStringAsFixed(0)}',
                      style: TextStyle(color: catTxs.isEmpty ? AppColors.textDim : color, fontSize: 15, fontWeight: FontWeight.w800, fontFamily: 'Syne')),
                  const Text('মোট', style: TextStyle(color: AppColors.textDim, fontSize: 11)),
                ]),
                const SizedBox(width: 6),
                Icon(Icons.chevron_right_rounded, color: color.withOpacity(0.5), size: 20),
              ]),
            ),
          );
        }),
      ],
    );
  }
}

// ── Category detail screen ─────────────────────────────────────────
class _CatDetailScreen extends ConsumerWidget {
  final AppCategory category;
  final Color color;
  const _CatDetailScreen({required this.category, required this.color});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final liveTxs = ref.watch(transactionsProvider).maybeWhen(
      data: (txs) => txs.where((t) => t.category == category.name).toList()
          ..sort((a, b) => b.date.compareTo(a.date)),
      orElse: () => <Transaction>[]);
    final total   = liveTxs.fold<double>(0, (s, t) => s + t.amount);
    final isIncome = category.type == TransactionType.income;

    return Scaffold(
      backgroundColor: AppColors.bg,
      appBar: AppBar(
        backgroundColor: AppColors.bg,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_ios_rounded, color: AppColors.textPrimary)),
        title: Row(children: [
          Text(category.icon, style: const TextStyle(fontSize: 22)), const SizedBox(width: 8),
          Text(category.name, style: const TextStyle(color: AppColors.textPrimary, fontFamily: 'Syne', fontWeight: FontWeight.w700, fontSize: 18)),
        ])),
      body: Column(children: [
        Padding(padding: const EdgeInsets.all(20),
          child: Container(padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(20),
              border: Border.all(color: color.withOpacity(0.25))),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('মোট ${isIncome ? 'আয়' : 'খরচ'}', style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
                const SizedBox(height: 4),
                Text('৳${total.toStringAsFixed(0)}',
                    style: TextStyle(color: color, fontSize: 28, fontWeight: FontWeight.w800, fontFamily: 'Syne')),
                Text('${liveTxs.length} টি লেনদেন', style: const TextStyle(color: AppColors.textMuted, fontSize: 12)),
              ]),
              Text(category.icon, style: const TextStyle(fontSize: 48)),
            ]))),
        liveTxs.isEmpty
            ? Expanded(child: Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Text(category.icon, style: const TextStyle(fontSize: 48)), const SizedBox(height: 12),
                Text('এই Category তে কোনো লেনদেন নেই', style: const TextStyle(color: AppColors.textMuted, fontSize: 14)),
                Text('Add ➕ থেকে "${category.name}" বেছে যোগ করো',
                    style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600), textAlign: TextAlign.center),
              ])))
            : Expanded(child: ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: liveTxs.length,
                itemBuilder: (_, i) {
                  final tx = liveTxs[i];
                  return Dismissible(
                    key: Key(tx.id), direction: DismissDirection.endToStart,
                    confirmDismiss: (_) async => blockIfDebtLinked(context, tx) ? false : await showDialog<bool>(context: context,
                      builder: (dCtx) => AlertDialog(
                        backgroundColor: const Color(0xFF141C2E),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                        title: const Text('Delete করবে?', style: TextStyle(color: AppColors.textPrimary, fontFamily: 'Syne', fontWeight: FontWeight.w700)),
                        content: Text('"${tx.note}" — ৳${tx.amount.toStringAsFixed(0)}', style: const TextStyle(color: AppColors.textMuted, fontSize: 13)),
                        actions: [
                          TextButton(onPressed: () => Navigator.pop(dCtx, false), child: const Text('না', style: TextStyle(color: AppColors.textMuted, fontSize: 15))),
                          ElevatedButton(onPressed: () => Navigator.pop(dCtx, true),
                            style: ElevatedButton.styleFrom(backgroundColor: AppColors.rose, foregroundColor: Colors.white,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                            child: const Text('হ্যাঁ, Delete')),
                        ])),
                    onDismissed: (_) => ref.read(transactionsProvider.notifier).remove(tx.id),
                    background: Container(margin: const EdgeInsets.only(bottom: 8),
                      decoration: BoxDecoration(color: AppColors.rose, borderRadius: BorderRadius.circular(16)),
                      alignment: Alignment.centerRight, padding: const EdgeInsets.only(right: 20),
                      child: const Icon(Icons.delete_rounded, color: Colors.white)),
                    child: Container(margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(14),
                      decoration: BoxDecoration(color: const Color(0xFF141C2E), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white.withOpacity(0.06))),
                      child: Row(children: [
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(tx.note, style: const TextStyle(color: AppColors.textPrimary, fontSize: 13, fontWeight: FontWeight.w600)),
                          Text('${tx.date.day}/${tx.date.month}/${tx.date.year}', style: const TextStyle(color: AppColors.textMuted, fontSize: 11)),
                        ])),
                        Text('${isIncome ? '+' : '-'}৳${tx.amount.toStringAsFixed(0)}',
                            style: TextStyle(color: color, fontSize: 14, fontWeight: FontWeight.w700, fontFamily: 'Syne')),
                      ])));
                })),
      ]),
    );
  }
}
