// lib/presentation/screens/lock/app_lock_layer.dart
//
// App-wide lock. Installed through MaterialApp.builder so it sits ABOVE the
// Navigator: pushed screens, dialogs and bottom sheets are all covered, not
// just the home route. While locked (or while the app is not in the
// foreground) the real UI is taken out of painting, hit-testing and the
// semantics tree with Offstage, but stays mounted so no state or form input
// is lost after unlocking.

import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../app/theme.dart';
import '../../../core/app_log.dart';
import '../../../data/security/app_lock_controller.dart';
import '../../../data/security/pin_service.dart';
import '../../providers/security_provider.dart';
import '../profile/profile_screen.dart' show profileProvider;

class AppLockLayer extends ConsumerStatefulWidget {
  final Widget child;
  const AppLockLayer({super.key, required this.child});
  @override
  ConsumerState<AppLockLayer> createState() => _AppLockLayerState();
}

class _AppLockLayerState extends ConsumerState<AppLockLayer>
    with WidgetsBindingObserver {
  late final AppLockController _ctrl;
  bool _checking = true;
  bool _covered = false; // privacy cover while not in the foreground

  @override
  void initState() {
    super.initState();
    _ctrl = AppLockController(now: ref.read(appLockClockProvider));
    WidgetsBinding.instance.addObserver(this);
    _init();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Future<void> _init() async {
    final pins = ref.read(pinServiceProvider);
    try {
      await pins.migrateLegacyIfNeeded();
    } catch (e, st) {
      appLog('AppLockLayer.migrate', e, st);
    }
    final loaded = await ref.read(lockSettingsProvider.notifier).reload();
    if (!mounted) return;
    final s = ref.read(lockSettingsProvider);
    setState(() {
      // A failed read is NEVER interpreted as "PIN disabled": the layer stays locked.
      _ctrl.start(
        pinEnabled: s.pinEnabled,
        timeout: s.timeout,
        settingsUnavailable: !loaded || s.loadFailed,
      );
      _checking = false;
    });
  }

  /// Tries to read the security settings again (button, or automatically when the
  /// app returns to the foreground while they are unavailable).
  void _retry() {
    setState(() => _checking = true);
    _init();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (_checking) return;
    switch (state) {
      case AppLifecycleState.inactive:
        // Brief interruption: hide content, but do not start the lock timer.
        if (_ctrl.pinEnabled) setState(() => _covered = true);
        break;
      case AppLifecycleState.hidden:
      case AppLifecycleState.paused:
        _ctrl.onBackground();
        if (_ctrl.pinEnabled) setState(() => _covered = true);
        break;
      case AppLifecycleState.resumed:
        if (_ctrl.settingsUnavailable) {
          // a transient read failure should not need manual intervention
          setState(() => _covered = false);
          _retry();
          break;
        }
        final locked = _ctrl.onForeground();
        if (locked) FocusManager.instance.primaryFocus?.unfocus();
        setState(() => _covered = false);
        break;
      case AppLifecycleState.detached:
        break;
    }
  }

  void _onUnlocked(String? notice) {
    setState(_ctrl.unlock);
    if (notice != null) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(notice)));
    }
  }

  @override
  Widget build(BuildContext context) {
    ref.listen<LockSettings>(lockSettingsProvider, (prev, next) {
      if (_checking) return;
      setState(() => _ctrl.updateSettings(
          pinEnabled: next.pinEnabled,
          timeout: next.timeout,
          settingsUnavailable: next.loadFailed));
    });

    final unavailable = !_checking && _ctrl.settingsUnavailable;
    final showPin = !_checking && _ctrl.locked && !unavailable;
    final hideContent = _checking || _ctrl.locked || _covered;

    return Stack(
      fit: StackFit.expand, // keeps full size even while the child is Offstage
      textDirection: TextDirection.ltr,
      children: [
        Offstage(offstage: hideContent, child: widget.child),
        if (_checking)
          const Positioned.fill(child: _LockBackdrop(spinner: true))
        else if (unavailable)
          Positioned.fill(child: _SecurityUnavailableScreen(onRetry: _retry))
        else if (showPin)
          Positioned.fill(child: PinEntryScreen(onUnlocked: _onUnlocked))
        else if (_covered)
          const Positioned.fill(child: _LockBackdrop()),
      ],
    );
  }
}

/// Shown instead of the app when the security settings cannot be read. There is no
/// way past it except reading the settings successfully (fail closed).
class _SecurityUnavailableScreen extends StatelessWidget {
  final VoidCallback onRetry;
  const _SecurityUnavailableScreen({required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(Icons.lock_rounded, color: AppColors.rose, size: 44),
                const SizedBox(height: 16),
                const Text('নিরাপত্তা সেটিং পড়া যাচ্ছে না',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: AppColors.textPrimary,
                        fontSize: 17,
                        fontWeight: FontWeight.w800,
                        fontFamily: 'Syne')),
                const SizedBox(height: 10),
                const Text(
                    'আপনার ডেটা সুরক্ষিত রাখতে অ্যাপ লক করে রাখা হয়েছে। আবার চেষ্টা করুন।',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: AppColors.textMuted, fontSize: 13, height: 1.5)),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: onRetry,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.gold,
                    foregroundColor: const Color(0xFF0A0E1A),
                  ),
                  child: const Text('আবার চেষ্টা করুন'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _LockBackdrop extends StatelessWidget {
  final bool spinner;
  const _LockBackdrop({this.spinner = false});
  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.bg,
      alignment: Alignment.center,
      child: spinner
          ? const CircularProgressIndicator(color: AppColors.gold)
          : const Icon(Icons.lock_rounded, color: AppColors.gold, size: 40),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// PIN entry (moved here from profile_screen.dart; look and feel unchanged)
// ═══════════════════════════════════════════════════════════════════════════
class PinEntryScreen extends ConsumerStatefulWidget {
  /// [notice] is non-null when the lock had to be reset (see PinOutcome.credentialMissing).
  final void Function(String? notice) onUnlocked;
  const PinEntryScreen({super.key, required this.onUnlocked});
  @override
  ConsumerState<PinEntryScreen> createState() => _PinEntryScreenState();
}

class _PinEntryScreenState extends ConsumerState<PinEntryScreen> {
  String _pin = '';
  bool _error = false;
  bool _busy = false;
  bool _unavailable = false;
  DateTime? _blockedUntil;
  Timer? _ticker;

  bool get _blocked =>
      _blockedUntil != null && DateTime.now().isBefore(_blockedUntil!);
  int get _secondsLeft => _blockedUntil == null
      ? 0
      : _blockedUntil!.difference(DateTime.now()).inSeconds + 1;

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }

  void _startBlock(Duration d) {
    _blockedUntil = DateTime.now().add(d);
    _ticker?.cancel();
    _ticker = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) return;
      if (!_blocked) t.cancel();
      setState(() {});
    });
  }

  void _add(String d) {
    if (_busy || _blocked || _pin.length >= 4) return;
    setState(() { _pin += d; _error = false; _unavailable = false; });
    if (_pin.length == 4) _verify();
  }

  void _back() {
    if (_busy || _pin.isEmpty) return;
    setState(() => _pin = _pin.substring(0, _pin.length - 1));
  }

  Future<void> _verify() async {
    setState(() => _busy = true);
    final entered = _pin;
    PinVerifyResult r;
    try {
      r = await ref.read(pinServiceProvider).verify(entered);
    } catch (e, st) {
      appLog('PinEntry.verify', e, st);
      r = const PinVerifyResult(PinOutcome.unavailable);
    }
    if (!mounted) return;

    switch (r.outcome) {
      case PinOutcome.ok:
        setState(() => _busy = false);
        widget.onUnlocked(null);
        return;
      case PinOutcome.credentialMissing:
        // Nothing can ever unlock the app: switch the lock off and tell the user.
        // Everything is captured BEFORE the awaits: reloading the lock settings
        // makes the lock layer remove this screen, after which `ref`/`mounted`
        // can no longer be used, but the notice must still be delivered.
        final notify = widget.onUnlocked;
        final pins = ref.read(pinServiceProvider);
        final lock = ref.read(lockSettingsProvider.notifier);
        final profile = ref.read(profileProvider.notifier);
        try {
          await pins.resetBrokenLock();
          await lock.reload();
          await profile.reload();
        } catch (e, st) {
          appLog('PinEntry.reset', e, st);
        }
        if (mounted) setState(() => _busy = false);
        notify(
            'PIN-এর তথ্য পাওয়া যায়নি, তাই লক বন্ধ করা হয়েছে। Profile থেকে নতুন PIN সেট করুন।');
        return;
      case PinOutcome.unavailable:
        HapticFeedback.heavyImpact();
        setState(() { _busy = false; _unavailable = true; _pin = ''; });
        return;
      case PinOutcome.throttled:
      case PinOutcome.wrong:
        HapticFeedback.heavyImpact();
        if (r.blockedFor != null) _startBlock(r.blockedFor!);
        setState(() { _busy = false; _error = true; _pin = ''; });
        return;
    }
  }

  Widget _numBtn(String label, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 72, height: 72,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.06),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.08)),
        ),
        alignment: Alignment.center,
        child: Text(label, style: const TextStyle(
          color: AppColors.textPrimary, fontSize: 24,
          fontWeight: FontWeight.w700, fontFamily: 'Syne',
        )),
      ),
    );
  }

  String get _statusText {
    if (_blocked) return '⏳ অনেকবার ভুল হয়েছে। $_secondsLeft সেকেন্ড পরে চেষ্টা করো';
    if (_unavailable) return '⚠️ নিরাপত্তা তথ্য এখন পড়া যাচ্ছে না। আবার চেষ্টা করো';
    if (_error) return '❌ ভুল PIN! আবার চেষ্টা করো';
    return '🔐 PIN দিয়ে unlock করো';
  }

  @override
  Widget build(BuildContext context) {
    final profile = ref.watch(profileProvider);
    final isProblem = _error || _blocked || _unavailable;
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            profile.photoPath != null && File(profile.photoPath!).existsSync()
                ? CircleAvatar(radius: 44, backgroundImage: FileImage(File(profile.photoPath!)))
                : Container(
                    width: 88, height: 88,
                    decoration: BoxDecoration(
                      gradient: AppColors.gradGold, shape: BoxShape.circle,
                      boxShadow: [BoxShadow(color: AppColors.gold.withOpacity(0.3), blurRadius: 20)],
                    ),
                    child: const Icon(Icons.person_rounded, color: Colors.white, size: 44),
                  ),
            const SizedBox(height: 16),
            Text(
              profile.name.isNotEmpty ? 'স্বাগতম, ${profile.name}!' : 'FinanceFlow',
              style: const TextStyle(color: AppColors.textPrimary, fontSize: 20,
                  fontWeight: FontWeight.w800, fontFamily: 'Syne'),
            ),
            const SizedBox(height: 8),
            Text(
              _statusText,
              textAlign: TextAlign.center,
              style: TextStyle(color: isProblem ? AppColors.rose : AppColors.textMuted, fontSize: 13),
            ),
            const SizedBox(height: 40),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(4, (i) => Container(
                margin: const EdgeInsets.symmetric(horizontal: 8),
                width: 16, height: 16,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: i < _pin.length ? AppColors.gold : Colors.white.withOpacity(0.15),
                ),
              )),
            ),
            const SizedBox(height: 48),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 60),
              child: Column(children: [
                Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: ['1','2','3'].map((d) => _numBtn(d, () => _add(d))).toList()),
                const SizedBox(height: 12),
                Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: ['4','5','6'].map((d) => _numBtn(d, () => _add(d))).toList()),
                const SizedBox(height: 12),
                Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: ['7','8','9'].map((d) => _numBtn(d, () => _add(d))).toList()),
                const SizedBox(height: 12),
                Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                  const SizedBox(width: 72),
                  _numBtn('0', () => _add('0')),
                  SizedBox(width: 72, height: 72,
                    child: GestureDetector(
                      onTap: _back,
                      child: Container(
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.06),
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: const Icon(Icons.backspace_outlined, color: AppColors.textMuted, size: 22),
                      ),
                    ),
                  ),
                ]),
              ]),
            ),
          ],
        ),
      ),
    );
  }
}
