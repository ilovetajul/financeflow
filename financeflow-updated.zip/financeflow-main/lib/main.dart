import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'app/bootstrap.dart';
import 'app/theme.dart';
import 'presentation/screens/home_shell.dart';
import 'presentation/screens/lock/app_lock_layer.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ),
  );
  SystemChrome.setPreferredOrientations(
      [DeviceOrientation.portraitUp]);

  runApp(const ProviderScope(child: FinanceFlowApp()));
}

class FinanceFlowApp extends StatelessWidget {
  const FinanceFlowApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'FinanceFlow',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark,
      // AppLock: Navigator-এর উপরে বসে, তাই push করা screen/dialog-ও ঢাকা থাকে।
      // PIN চালু থাকলে অ্যাপ চালুর সময় এবং (timeout অনুযায়ী) ব্যাকগ্রাউন্ড থেকে ফিরলে lock হয়।
      builder: (context, child) => AppLockLayer(child: child ?? const SizedBox.shrink()),
      home: const BootstrapGate(child: HomeShell()),
    );
  }
}
