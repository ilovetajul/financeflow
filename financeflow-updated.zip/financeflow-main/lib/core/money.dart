// lib/core/money.dart
//
// Central place for amount parsing/validation and Taka formatting.
// Stored values are never changed by formatting; formatting is display-only.

/// Result of parsing a user-typed amount.
class AmountResult {
  final double? value;
  final String? error; // Bengali, user-facing. Null when [value] is valid.
  const AmountResult.ok(double this.value) : error = null;
  const AmountResult.fail(String this.error) : value = null;
  bool get isValid => value != null;
}

class Money {
  Money._();

  /// Largest amount accepted from the user (৳99,99,99,999.99).
  static const double maxAmount = 999999999.99;

  static const String errEmpty = 'দয়া করে পরিমাণ লিখুন।';
  static const String errInvalid = 'দয়া করে একটি সঠিক পরিমাণ লিখুন।';
  static const String errZero = 'পরিমাণ শূন্যের চেয়ে বেশি হতে হবে।';
  static const String errNegative = 'পরিমাণ ঋণাত্মক হতে পারবে না।';
  static const String errTooLarge = 'পরিমাণটি অনেক বড়। দয়া করে যাচাই করুন।';

  static const _bnDigits = {
    '০': '0', '১': '1', '২': '2', '৩': '3', '৪': '4',
    '৫': '5', '৬': '6', '৭': '7', '৮': '8', '৯': '9',
  };

  /// Converts Bengali digits to ASCII and strips grouping/currency symbols.
  static String normalize(String input) {
    final sb = StringBuffer();
    for (final ch in input.trim().split('')) {
      if (_bnDigits.containsKey(ch)) {
        sb.write(_bnDigits[ch]);
      } else if (ch == ',' || ch == '৳' || ch == ' ' || ch == '\u00A0') {
        continue; // grouping separator / currency sign / spaces
      } else {
        sb.write(ch);
      }
    }
    return sb.toString();
  }

  /// Safe parse for user input. Never throws.
  /// Accepts "1,250.50", "৳১২৫০", "100". Rejects empty, text, exponent
  /// notation, NaN/Infinity, zero (unless [allowZero]), negatives and
  /// values above [maxAmount]. Result is rounded to 2 decimals.
  static AmountResult parse(String? input, {bool allowZero = false}) {
    if (input == null || input.trim().isEmpty) {
      return const AmountResult.fail(errEmpty);
    }
    final s = normalize(input);
    if (s.startsWith('-')) return const AmountResult.fail(errNegative);
    // digits with an optional single decimal part only
    if (!RegExp(r'^\d+(\.\d{1,8})?$|^\.\d{1,8}$').hasMatch(s)) {
      return const AmountResult.fail(errInvalid);
    }
    final v = double.tryParse(s);
    if (v == null || v.isNaN || v.isInfinite) {
      return const AmountResult.fail(errInvalid);
    }
    final rounded = (v * 100).roundToDouble() / 100;
    if (rounded == 0 && !allowZero) return const AmountResult.fail(errZero);
    if (rounded > maxAmount) return const AmountResult.fail(errTooLarge);
    return AmountResult.ok(rounded);
  }

  /// Text to put back into an amount field: "500" or "100.5" / "100.55".
  static String toInputText(double v) {
    if (v == v.roundToDouble()) return v.toStringAsFixed(0);
    var s = v.toStringAsFixed(2);
    if (s.endsWith('0')) s = s.substring(0, s.length - 1);
    return s;
  }

  /// "৳1,000", "৳10,00,000", "৳1,250.50". Bangladeshi (lakh/crore) grouping.
  /// Display only: does not change the stored number.
  static String format(double v, {bool symbol = true}) {
    if (v.isNaN || v.isInfinite) return symbol ? '৳0' : '0';
    final neg = v < 0;
    final abs = v.abs();
    final fixed = abs.toStringAsFixed(2);
    final parts = fixed.split('.');
    final intPart = parts[0];
    final frac = parts[1] == '00' ? '' : '.${parts[1]}';
    String grouped;
    if (intPart.length <= 3) {
      grouped = intPart;
    } else {
      final last3 = intPart.substring(intPart.length - 3);
      var rest = intPart.substring(0, intPart.length - 3);
      final chunks = <String>[];
      while (rest.length > 2) {
        chunks.insert(0, rest.substring(rest.length - 2));
        rest = rest.substring(0, rest.length - 2);
      }
      if (rest.isNotEmpty) chunks.insert(0, rest);
      grouped = '${chunks.join(',')},$last3';
    }
    return '${neg ? '-' : ''}${symbol ? '৳' : ''}$grouped$frac';
  }
}
