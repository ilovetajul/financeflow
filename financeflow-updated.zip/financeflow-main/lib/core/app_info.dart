// lib/core/app_info.dart
/// Keep in sync with `version:` in pubspec.yaml (build number omitted).
class AppInfo {
  AppInfo._();
  static const String name = 'FinanceFlow';
  static const String version = '1.0.0';
}
