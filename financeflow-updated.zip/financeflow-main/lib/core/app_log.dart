// lib/core/app_log.dart
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart' show PlatformException;

/// Development-only logging. Never pass PINs, amounts, notes, names or backup
/// contents here – only operation names and exception types.
void appLog(String where, Object error, [StackTrace? st]) {
  if (kDebugMode) {
    debugPrint('[FinanceFlow] $where: ${error.runtimeType}');
  }
}

/// Short, privacy-safe description of an error that is OK to show on screen and
/// to log in release builds: the exception type and, for plugin errors, the
/// error code plus a sanitised message (for example google_sign_in's
/// `sign_in_failed` with `ApiException: 10`). E-mail addresses and token-like
/// strings are removed and the text is truncated. Stack traces and the
/// `details` field are never included.
String describeError(Object error) {
  final type = error.runtimeType.toString();
  if (error is PlatformException) {
    final msg = _sanitize(error.message ?? '');
    return '$type code=${error.code}${msg.isEmpty ? '' : ' message=$msg'}';
  }
  return type;
}

/// Diagnostic log that also works in RELEASE builds (visible in `adb logcat`
/// as `I/flutter`). Only the output of [describeError] is logged.
void logDiagnostic(String where, Object error) {
  debugPrint('[FinanceFlow] $where: ${describeError(error)}');
}

String _sanitize(String s) {
  var out = s
      // e-mail addresses
      .replaceAll(RegExp(r'[\w.+\-]+@[\w\-]+(?:\.[\w\-]+)+'), '<email>')
      // long token-like runs (they contain a digit); plain class names such as
      // com.google.android.gms.common.api.ApiException contain none and survive
      .replaceAll(RegExp(r'(?=[A-Za-z0-9_\-.]*\d)[A-Za-z0-9_\-.]{32,}'), '<redacted>')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
  if (out.length > 160) out = '${out.substring(0, 160)}…';
  return out;
}
