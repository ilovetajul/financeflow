// lib/app/bootstrap.dart
//
// Opens the database (running schema upgrades) and performs the one-time,
// verified SharedPreferences → SQLite data migration BEFORE any screen that
// reads financial data is built. If something fails the user sees a clear
// message and can retry; no data is touched or deleted.

import 'package:flutter/material.dart';
import '../core/app_log.dart';
import '../data/local/database_helper.dart';
import '../data/local/migration_service.dart';
import 'theme.dart';

class BootstrapGate extends StatefulWidget {
  final Widget child;
  const BootstrapGate({super.key, required this.child});

  @override
  State<BootstrapGate> createState() => _BootstrapGateState();
}

class _BootstrapGateState extends State<BootstrapGate> {
  bool _ready = false;
  bool _running = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _boot();
  }

  Future<void> _boot() async {
    setState(() { _running = true; _error = null; });
    try {
      await DatabaseHelper.instance.database;
      final r = await MigrationService().runIfNeeded();
      if (!mounted) return;
      setState(() {
        _running = false;
        _ready = r.success;
        _error = r.success ? null : r.userMessage;
      });
    } catch (e, st) {
      appLog('BootstrapGate', e, st);
      if (!mounted) return;
      setState(() {
        _running = false;
        _ready = false;
        _error = 'ডেটাবেস চালু করা যায়নি। আপনার ডেটা মোছা হয়নি। আবার চেষ্টা করুন।';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_ready) return widget.child;
    return Scaffold(
      backgroundColor: AppColors.bg,
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: _running
              ? const Column(mainAxisSize: MainAxisSize.min, children: [
                  CircularProgressIndicator(color: AppColors.gold),
                  SizedBox(height: 16),
                  Text('ডেটা প্রস্তুত হচ্ছে…',
                      style: TextStyle(color: AppColors.textMuted)),
                ])
              : Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.error_outline, color: AppColors.rose, size: 40),
                  const SizedBox(height: 12),
                  Text(_error ?? 'কিছু একটা ভুল হয়েছে।',
                      textAlign: TextAlign.center,
                      style: const TextStyle(color: AppColors.textPrimary, height: 1.5)),
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: _boot,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.gold,
                      foregroundColor: const Color(0xFF0A0E1A),
                    ),
                    child: const Text('আবার চেষ্টা করুন'),
                  ),
                ]),
        ),
      ),
    );
  }
}
